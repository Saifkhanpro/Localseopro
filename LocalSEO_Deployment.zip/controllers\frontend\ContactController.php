<?php
namespace Controllers\Frontend;
use Core\Controller;
use Core\Helpers;
use Core\Mailer;
use Models\Lead;
use Models\Setting;

class ContactController extends Controller {
    public function index() {
        $settingModel = new Setting();
        
        $data = [
            'pageTitle' => 'Contact Us - Local SEO Experts | LocalSEO.pk',
            'metaDescription' => 'Get in touch with LocalSEO.pk. Fill out our contact form to request a free SEO audit or discuss how we can grow your local business.',
            'canonicalUrl' => APP_URL . '/contact',
            'business_phone' => Helpers::setting('seo_business_phone', '+92 300 1234567'),
            'business_email' => Helpers::setting('admin_email', 'info@localseo.pk'),
            'business_address' => Helpers::setting('seo_business_street', '') . ', ' . Helpers::setting('seo_business_city', ''),
            'maps_embed' => Helpers::setting('contact_map_embed', '')
        ];

        $this->frontendView('contact/index', $data);
    }

    public function submit() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('/contact');
        }

        $this->verifyCsrf();

        // Basic Honeypot check
        if (!empty($_POST['website_url_hp'])) {
            // Bot detected, silently drop
            Helpers::flash('success', 'Thank you! Your message has been sent successfully.');
            $this->redirect('/contact');
            return;
        }

        $rules = [
            'full_name' => 'required|max:100',
            'email' => 'required|email|max:150',
            'phone' => 'required|max:20',
            'service_needed' => 'required',
            'message' => 'required'
        ];

        $errors = $this->validate($rules);

        if (!empty($errors)) {
            $_SESSION['form_errors'] = $errors;
            $_SESSION['form_data'] = $_POST;
            Helpers::flash('error', 'Please correct the errors before submitting.');
            $this->redirect('/contact');
            return;
        }

        $leadModel = new Lead();
        $data = [
            'full_name' => $this->security->sanitizeInput($this->input('full_name')),
            'email' => $this->security->sanitizeInput($this->input('email')),
            'phone' => $this->security->sanitizeInput($this->input('phone')),
            'whatsapp_number' => $this->security->sanitizeInput($this->input('whatsapp_number')),
            'city' => $this->security->sanitizeInput($this->input('city')),
            'service_needed' => $this->security->sanitizeInput($this->input('service_needed')),
            'message' => $this->security->sanitizeInput($this->input('message')),
            'ip_address' => $this->security->getClientIP(),
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
            'source_url' => $_SERVER['HTTP_REFERER'] ?? '',
            'status' => 'new',
            'is_read' => 0
        ];

        try {
            $leadId = $leadModel->create($data);
            
            // Send email notification
            if (Helpers::setting('email_notifications_enabled', '1') === '1') {
                Mailer::sendContactNotification($data);
            }

            Helpers::flash('success', 'Thank you! Your message has been sent successfully. We will get back to you shortly.');
        } catch (\Exception $e) {
            Helpers::flash('error', 'An error occurred while saving your message. Please try again later.');
            error_log('Lead submission error: ' . $e->getMessage());
        }

        $this->redirect('/contact');
    }
}

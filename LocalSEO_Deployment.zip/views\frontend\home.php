<?php ob_start(); ?>

<!-- Hero Section -->
<section class="hero-section bg-light py-5 py-xl-6 position-relative overflow-hidden">
    <div class="container position-relative z-1 py-5">
        <div class="row align-items-center">
            <div class="col-lg-6 mb-5 mb-lg-0">
                <span class="badge bg-primary-subtle text-primary rounded-pill px-3 py-2 mb-3 fw-semibold">
                    #1 Local SEO Agency in Pakistan
                </span>
                <h1 class="display-4 fw-bolder mb-4 text-dark lh-sm">
                    Dominate Local Search & <span class="text-primary text-decoration-underline">Drive More Customers</span>
                </h1>
                <p class="lead text-muted mb-5 pe-lg-5">
                    We help Pakistani businesses rank #1 on Google Maps and Local Search. Get more calls, foot traffic, and revenue with proven local SEO strategies.
                </p>
                <div class="d-flex flex-column flex-sm-row gap-3">
                    <a href="/contact" class="btn btn-primary btn-lg rounded-pill px-5 py-3 fw-bold shadow-sm">
                        Get Free SEO Audit <i class="bi bi-arrow-right ms-2"></i>
                    </a>
                    <a href="/services" class="btn btn-outline-dark btn-lg rounded-pill px-5 py-3 fw-bold">
                        View Our Services
                    </a>
                </div>
                <div class="mt-4 pt-3 d-flex align-items-center gap-3">
                    <div class="d-flex">
                        <i class="bi bi-star-fill text-warning"></i>
                        <i class="bi bi-star-fill text-warning"></i>
                        <i class="bi bi-star-fill text-warning"></i>
                        <i class="bi bi-star-fill text-warning"></i>
                        <i class="bi bi-star-fill text-warning"></i>
                    </div>
                    <span class="text-muted fw-medium border-start ps-3 border-2">Rated 5.0 by 100+ Local Businesses</span>
                </div>
            </div>
            <div class="col-lg-6 position-relative">
                <div class="position-absolute top-50 start-50 translate-middle w-100 h-100 bg-primary opacity-10 rounded-circle filter-blur-3" style="filter: blur(80px); z-index:-1;"></div>
                <img src="/assets/images/hero-illustration.webp" alt="Local SEO Dashboard Analytics" class="img-fluid rounded-4 shadow-lg border border-white border-4" onerror="this.src='https://placehold.co/800x600/2563eb/white?text=SEO+Dashboard+Mockup'">
            </div>
        </div>
    </div>
</section>

<!-- Dynamic Content Blocks (Pages content injected here if not empty) -->
<?php if (!empty($page['content'])): ?>
<section class="py-5">
    <div class="container">
        <div class="content-formatted">
            <?= $page['content'] ?>
        </div>
    </div>
</section>
<?php endif; ?>

<!-- Services Grid -->
<section class="py-5 py-lg-6 bg-white" id="services">
    <div class="container py-4">
        <div class="text-center max-w-700 mx-auto mb-5 pb-3">
            <h2 class="fw-bolder fs-1 mb-3">Comprehensive Local SEO Solutions</h2>
            <p class="text-muted lead">Everything you need to outrank competitors and capture local search intent.</p>
        </div>
        
        <div class="row g-4 d-flex justify-content-center">
            <?php foreach ($services as $service): ?>
            <div class="col-xl-4 col-md-6">
                <div class="card h-100 border-0 shadow-sm rounded-4 service-card transition-all">
                    <div class="card-body p-4 p-lg-5">
                        <div class="icon-box bg-primary-subtle text-primary rounded-circle mb-4 d-inline-flex align-items-center justify-content-center" style="width:70px;height:70px;font-size:2rem;">
                            <i class="<?= \Core\Helpers::escape($service['icon_class'] ?: 'bi bi-graph-up-arrow') ?>"></i>
                        </div>
                        <h3 class="h4 fw-bold mb-3"><?= \Core\Helpers::escape($service['title']) ?></h3>
                        <p class="text-muted mb-4"><?= \Core\Helpers::escape($service['short_description']) ?></p>
                        <a href="/services/<?= \Core\Helpers::escape($service['slug']) ?>" class="fw-semibold text-primary text-decoration-none stretched-link d-inline-flex align-items-center">
                            Learn More <i class="bi bi-arrow-right ms-2 transition-transform"></i>
                        </a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        
        <div class="text-center mt-5 pt-4">
            <a href="/services" class="btn btn-outline-primary rounded-pill px-4 py-2 border-2 fw-bold">View All SEO Services</a>
        </div>
    </div>
</section>

<!-- Case Studies Highlight -->
<section class="py-5 py-lg-6 bg-light">
    <div class="container py-4">
        <div class="row align-items-center mb-5 pb-2">
            <div class="col-lg-8 mb-4 mb-lg-0">
                <h2 class="fw-bolder fs-1 mb-2">Proven Results for Pakistani Businesses</h2>
                <p class="text-muted lead mb-0">Don't just take our word for it. See how we've transformed local search visibility to drive actual revenue.</p>
            </div>
            <div class="col-lg-4 text-lg-end">
                <a href="/case-studies" class="btn btn-dark rounded-pill px-4 py-2 fw-bold">See All Case Studies</a>
            </div>
        </div>

        <div class="row g-4">
            <?php foreach ($case_studies as $case): ?>
            <div class="col-md-6 col-lg-4 d-flex">
                <div class="card border-0 shadow-sm rounded-4 overflow-hidden flex-fill case-study-card">
                    <div class="card-body p-4 d-flex flex-column">
                        <span class="badge bg-success-subtle text-success mb-3 align-self-start fw-bold px-3 py-2 rounded-pill"><?= \Core\Helpers::escape($case['industry']) ?></span>
                        <h4 class="fw-bold mb-3"><a href="/case-studies/<?= \Core\Helpers::escape($case['slug']) ?>" class="text-dark text-decoration-none stretched-link"><?= \Core\Helpers::escape($case['title']) ?></a></h4>
                        
                        <div class="mt-auto pt-4 border-top">
                            <div class="row text-center g-2 w-100">
                                <div class="col-6 border-end">
                                    <h5 class="fw-bolder h3 text-primary mb-0">+350%</h5>
                                    <span class="text-muted small">Organic Traffic</span>
                                </div>
                                <div class="col-6">
                                    <h5 class="fw-bolder h3 text-success mb-0">Top 3</h5>
                                    <span class="text-muted small">Map Rankings</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- CTA Section -->
<section class="py-6 bg-primary text-white position-relative overflow-hidden w-100 style="min-height: 400px;">
    <div class="position-absolute top-0 start-0 w-100 h-100 bg-pattern opacity-10"></div>
    <div class="container py-5 position-relative z-1 text-center">
        <h2 class="display-5 fw-bolder mb-4">Ready to Dominate Your Local Market?</h2>
        <p class="lead mb-5 opacity-85 max-w-700 mx-auto">Get a free, comprehensive local SEO audit for your business. We'll identify exactly what's holding your rankings back and give you an actionable roadmap.</p>
        <a href="/contact" class="btn btn-light btn-lg text-primary rounded-pill px-5 py-3 fw-bold shadow">
            Get My Free SEO Audit Now
        </a>
    </div>
</section>

<style>
    .py-6 { padding-top: 5rem!important; padding-bottom: 5rem!important; }
    .max-w-700 { max-width: 700px; }
    .transition-all { transition: all 0.3s ease; }
    .service-card:hover { transform: translateY(-10px); box-shadow: 0 1rem 3rem rgba(0,0,0,.1)!important; }
    .service-card:hover .icon-box { background-color: var(--primary-color)!important; color: white!important; }
    .service-card a:hover i { transform: translateX(5px); }
    .case-study-card:hover { transform: translateY(-5px); }
</style>

<?php
$content = ob_get_clean();
require VIEW_PATH . '/frontend/_layout.php';
?>

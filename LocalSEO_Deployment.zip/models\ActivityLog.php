<?php
namespace Models;
use Core\Model;

class ActivityLog extends Model {
    protected $table = 'activity_log';
    protected $fillable = [
        'user_id', 'action', 'entity_type', 'entity_id', 'description', 'ip_address', 'user_agent'
    ];
}

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - LocalSEO.pk Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #f8f9fa; display: flex; align-items: center; justify-content: center; height: 100vh; font-family: 'Inter', sans-serif; }
        .login-card { width: 100%; max-width: 400px; padding: 2rem; background: white; border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,0.05); }
        .login-card .logo { text-align: center; margin-bottom: 2rem; font-size: 1.5rem; font-weight: 700; color: #2563eb; }
        .btn-primary { background: #2563eb; border-color: #2563eb; width: 100%; padding: 0.75rem; font-weight: 600; border-radius: 6px; }
        .btn-primary:hover { background: #1d4ed8; border-color: #1d4ed8; }
        .form-control { padding: 0.75rem; border-radius: 6px; }
    </style>
</head>
<body>

<div class="login-card">
    <div class="logo">
        LocalSEO.pk Panel
    </div>

    <?php if (isset($_SESSION['flash_error'])): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($_SESSION['flash_error']) ?></div>
        <?php unset($_SESSION['flash_error']); ?>
    <?php endif; ?>
    <?php if (isset($_SESSION['flash_success'])): ?>
        <div class="alert alert-success"><?= htmlspecialchars($_SESSION['flash_success']) ?></div>
        <?php unset($_SESSION['flash_success']); ?>
    <?php endif; ?>

    <form action="/admin/login/process" method="POST">
        <input type="hidden" name="csrf_token" value="<?= \Core\CSRF::generate() ?>">
        <div class="mb-3">
            <label class="form-label text-muted small fw-bold uppercase">Username or Email</label>
            <input type="text" name="username" class="form-control" required autofocus autocomplete="username">
        </div>
        <div class="mb-4">
            <label class="form-label text-muted small fw-bold uppercase">Password</label>
            <input type="password" name="password" class="form-control" required autocomplete="current-password">
        </div>
        <button type="submit" class="btn btn-primary">Sign In to Dashboard</button>
    </form>
    
    <div class="text-center mt-4 text-muted small">
        &copy; <?= date('Y') ?> LocalSEO.pk. All rights reserved.
    </div>
</div>

</body>
</html>

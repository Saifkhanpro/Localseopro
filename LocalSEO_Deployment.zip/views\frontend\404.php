<?php 
// 404 Page Template
$pageTitle = $pageTitle ?? 'Page Not Found - 404Error';
$metaDescription = 'The page you are looking for might have been removed, had its name changed, or is temporarily unavailable.';
$robots = ['noindex', 'follow'];

ob_start(); 
?>

<div class="container py-7 text-center">
    <div class="row justify-content-center">
        <div class="col-lg-8 col-xl-6 py-5">
            <!-- 404 Illustration placeholder -->
            <div class="position-relative d-inline-block mb-5">
                <i class="bi bi-file-earmark-x-fill text-primary opacity-25" style="font-size: 12rem; line-height: 1; display: block;"></i>
                <h1 class="position-absolute top-50 start-50 translate-middle fw-bolder text-dark mb-0" style="font-size: 4rem; text-shadow: 2px 2px 0 #fff, -2px -2px 0 #fff, 2px -2px 0 #fff, -2px 2px 0 #fff;">404</h1>
            </div>
            
            <h2 class="display-5 fw-bolder mb-3 text-dark lh-sm">Oops! That page<br>can't be found.</h2>
            <p class="lead text-muted mb-5">It looks like nothing was found at this location. It might have been removed, renamed, or did not exist in the first place.</p>
            
            <div class="d-flex flex-column flex-sm-row justify-content-center gap-3">
                <a href="/" class="btn btn-primary btn-lg rounded-pill px-5 py-3 fw-bold shadow-sm">
                    <i class="bi bi-house-door-fill me-2"></i> Return to Homepage
                </a>
                <a href="/contact" class="btn btn-outline-dark btn-lg rounded-pill px-5 py-3 fw-bold">
                    Report an Issue
                </a>
            </div>
            
            <div class="mt-5 pt-4">
                <p class="text-muted small fw-medium tracking-wide text-uppercase mb-3">Or try exploring these sections:</p>
                <div class="d-flex justify-content-center gap-3 flex-wrap">
                    <a href="/services" class="badge bg-light text-dark text-decoration-none border px-3 py-2 fs-6 hover-primary transition-all">SEO Services</a>
                    <a href="/local-seo" class="badge bg-light text-dark text-decoration-none border px-3 py-2 fs-6 hover-primary transition-all">Locations</a>
                    <a href="/case-studies" class="badge bg-light text-dark text-decoration-none border px-3 py-2 fs-6 hover-primary transition-all">Case Studies</a>
                    <a href="/blog" class="badge bg-light text-dark text-decoration-none border px-3 py-2 fs-6 hover-primary transition-all">SEO Blog</a>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .py-7 { padding-top: 8rem!important; padding-bottom: 8rem!important; }
    .tracking-wide { letter-spacing: 0.05em; }
    .hover-primary:hover { color: var(--primary-color)!important; border-color: var(--primary-color)!important; background-color: white!important;}
    .transition-all { transition: all 0.2s ease; }
</style>

<?php
$content = ob_get_clean();
require VIEW_PATH . '/frontend/_layout.php';
?>

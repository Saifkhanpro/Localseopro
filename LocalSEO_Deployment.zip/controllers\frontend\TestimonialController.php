<?php
namespace Controllers\Frontend;
use Core\Controller;
class TestimonialController extends Controller {
    public function index() {
        echo "<h1>Testimonials</h1><p>Client testimonials page (stub).</p>";
    }
}

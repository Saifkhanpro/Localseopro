<?php
namespace Models;
use Core\Model;

class MenuItem extends Model {
    protected $table = 'menu_items';
    protected $fillable = ['menu_id', 'parent_id', 'title', 'url', 'target', 'css_classes', 'order_index'];
}

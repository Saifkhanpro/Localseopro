<?php
// Known version history for rollback compatibility
return [
    '1.0.0' => ['date' => '2026-03-12', 'db_version' => '1.0.0', 'min_php' => '8.0.0'],
];

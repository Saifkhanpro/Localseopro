<?php
namespace Core;

class CSVExporter {
    public static function export(array $data, array $headers, string $filename): void {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '.csv"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
        header('Pragma: public');

        // Output BOM for Excel UTF-8 compatibility
        echo "\xEF\xBB\xBF";

        $output = fopen('php://output', 'w');
        fputcsv($output, $headers);

        foreach ($data as $row) {
            fputcsv($output, $row);
        }

        fclose($output);
        exit;
    }

    public static function queryToCsv(string $sql, array $params, array $headers, string $filename): void {
        $db = Database::getInstance();
        $stmt = $db->query($sql, $params);
        
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '.csv"');
        // Output BOM for Excel UTF-8 compatibility
        echo "\xEF\xBB\xBF";
        $output = fopen('php://output', 'w');
        fputcsv($output, $headers);

        while ($row = $stmt->fetch(\PDO::FETCH_NUM)) {
            fputcsv($output, $row);
        }

        fclose($output);
        exit;
    }
}

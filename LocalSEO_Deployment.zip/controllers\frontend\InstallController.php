<?php
namespace Controllers\Frontend;
use Core\Controller;
use Core\Database;

class InstallController extends Controller {
    public function index() {
        if (file_exists(ROOT_PATH . '/config.php') && defined('DB_HOST')) {
            die('Installation appears to be complete or config.php exists. Delete config.php to reinstall or access the admin panel.');
        }

        $minPhp = defined('LSEO_MIN_PHP') ? LSEO_MIN_PHP : '8.0.0';
        $checks = [
            'php' => version_compare(PHP_VERSION, $minPhp, '>='),
            'pdo' => extension_loaded('pdo_mysql'),
            'gd' => extension_loaded('gd'),
            'curl' => extension_loaded('curl'),
            'zip' => extension_loaded('zip'),
            'mbstring' => extension_loaded('mbstring'),
            'json' => extension_loaded('json'),
            'uploads' => is_writable(ROOT_PATH . '/uploads'),
            'cache' => is_writable(ROOT_PATH . '/cache'),
            'root' => is_writable(ROOT_PATH)
        ];

        $allGood = !in_array(false, $checks, true);

        // Simple raw PHP view for installation
        require VIEW_PATH . '/install/step1.php';
    }

    public function process() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') die('Invalid request');

        $dbHost = $_POST['db_host'] ?? 'localhost';
        $dbName = $_POST['db_name'] ?? '';
        $dbUser = $_POST['db_user'] ?? '';
        $dbPass = $_POST['db_pass'] ?? '';
        $dbPrefix = $_POST['db_prefix'] ?? 'lseo_';
        $adminUser = $_POST['admin_user'] ?? '';
        $adminEmail = $_POST['admin_email'] ?? '';
        $adminPass = $_POST['admin_pass'] ?? '';

        if (empty($dbName) || empty($dbUser) || empty($adminUser) || empty($adminEmail) || empty($adminPass)) {
            die('Please fill all required fields. <a href="javascript:history.back()">Go back</a>');
        }

        try {
            $pdo = current(Database::createConnection($dbHost, $dbName, $dbUser, $dbPass));
        } catch (\Exception $e) {
            die('Database connection failed: ' . $e->getMessage() . ' <a href="javascript:history.back()">Go back</a>');
        }

        // Install Schema
        try {
            $this->createTables($pdo, $dbPrefix);
            $this->seedData($pdo, $dbPrefix, $adminUser, $adminEmail, $adminPass);
            $this->writeConfig($dbHost, $dbName, $dbUser, $dbPass, $dbPrefix);
        } catch (\Exception $e) {
            die('Installation failed during setup: ' . $e->getMessage());
        }

        // Redirect to success/login
        header('Location: /admin/login?installed=1');
        exit;
    }

    private function createTables(\PDO $pdo, string $prefix) {
        $queries = [
            // Users
            "CREATE TABLE IF NOT EXISTS `{$prefix}users` (
                `id` INT AUTO_INCREMENT PRIMARY KEY,
                `username` VARCHAR(50) NOT NULL UNIQUE,
                `email` VARCHAR(150) NOT NULL UNIQUE,
                `password` VARCHAR(255) NOT NULL,
                `display_name` VARCHAR(100),
                `first_name` VARCHAR(50),
                `last_name` VARCHAR(50),
                `role` ENUM('subscriber','contributor','author','editor','admin','super_admin') DEFAULT 'subscriber',
                `seo_role` ENUM('none','analyzer','manager') DEFAULT 'none',
                `avatar_id` INT NULL,
                `bio` TEXT,
                `website` VARCHAR(255),
                `social_facebook` VARCHAR(255),
                `social_twitter` VARCHAR(255),
                `social_linkedin` VARCHAR(255),
                `social_instagram` VARCHAR(255),
                `is_active` TINYINT(1) DEFAULT 1,
                `login_attempts` INT DEFAULT 0,
                `locked_until` DATETIME NULL,
                `last_login` DATETIME NULL,
                `last_login_ip` VARCHAR(45),
                `session_token` VARCHAR(64) NULL,
                `last_activity` DATETIME NULL,
                `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                INDEX (`role`), INDEX (`session_token`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;",

            // Settings
            "CREATE TABLE IF NOT EXISTS `{$prefix}settings` (
                `id` INT AUTO_INCREMENT PRIMARY KEY,
                `setting_group` VARCHAR(50) NOT NULL DEFAULT 'general',
                `setting_key` VARCHAR(100) NOT NULL UNIQUE,
                `setting_value` LONGTEXT,
                `is_autoload` TINYINT(1) DEFAULT 1,
                INDEX (`setting_group`), INDEX (`is_autoload`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;",

            // Media
            "CREATE TABLE IF NOT EXISTS `{$prefix}media` (
                `id` INT AUTO_INCREMENT PRIMARY KEY,
                `file_name` VARCHAR(255) NOT NULL,
                `original_name` VARCHAR(255),
                `file_path` VARCHAR(255) NOT NULL,
                `file_type` VARCHAR(50),
                `mime_type` VARCHAR(100),
                `file_size` BIGINT,
                `title` VARCHAR(255),
                `alt_text` VARCHAR(255),
                `caption` TEXT,
                `description` TEXT,
                `uploaded_by` INT,
                `width` INT,
                `height` INT,
                `is_optimized` TINYINT(1) DEFAULT 0,
                `optimized_size` BIGINT,
                `optimization_date` DATETIME,
                `webp_path` VARCHAR(255) NULL,
                `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX (`file_type`), INDEX (`uploaded_by`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;",

            // Posts (Blog)
            "CREATE TABLE IF NOT EXISTS `{$prefix}posts` (
                `id` INT AUTO_INCREMENT PRIMARY KEY,
                `author_id` INT NOT NULL,
                `title` VARCHAR(255) NOT NULL,
                `slug` VARCHAR(255) NOT NULL UNIQUE,
                `content` LONGTEXT,
                `excerpt` TEXT,
                `status` ENUM('draft', 'pending', 'private', 'published', 'trash') DEFAULT 'draft',
                `post_type` VARCHAR(20) DEFAULT 'post',
                `visibility` ENUM('public', 'private', 'password') DEFAULT 'public',
                `password` VARCHAR(255) NULL,
                `featured_image_id` INT NULL,
                `comment_status` ENUM('open', 'closed') DEFAULT 'open',
                `ping_status` ENUM('open', 'closed') DEFAULT 'open',
                `focus_keyword` VARCHAR(255),
                `secondary_keywords` TEXT,
                `seo_title` VARCHAR(255),
                `meta_description` TEXT,
                `robots_index` ENUM('default','index','noindex') DEFAULT 'default',
                `robots_follow` ENUM('default','follow','nofollow') DEFAULT 'default',
                `robots_advanced` VARCHAR(255),
                `canonical_url` VARCHAR(255),
                `primary_category_id` INT NULL,
                `readability_score` INT DEFAULT 0,
                `seo_score` INT DEFAULT 0,
                `schema_type` VARCHAR(50) DEFAULT 'Article',
                `schema_data` JSON NULL,
                `published_at` DATETIME NULL,
                `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                INDEX (`status`), INDEX (`post_type`), INDEX (`author_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;",

            // Pages
            "CREATE TABLE IF NOT EXISTS `{$prefix}pages` (
                `id` INT AUTO_INCREMENT PRIMARY KEY,
                `author_id` INT NOT NULL,
                `title` VARCHAR(255) NOT NULL,
                `slug` VARCHAR(255) NOT NULL UNIQUE,
                `content` LONGTEXT,
                `status` ENUM('draft', 'pending', 'private', 'published', 'trash') DEFAULT 'draft',
                `visibility` ENUM('public', 'private', 'password') DEFAULT 'public',
                `password` VARCHAR(255) NULL,
                `featured_image_id` INT NULL,
                `parent_id` INT NULL,
                `template` VARCHAR(100) DEFAULT 'default',
                `order_index` INT DEFAULT 0,
                `focus_keyword` VARCHAR(255),
                `secondary_keywords` TEXT,
                `seo_title` VARCHAR(255),
                `meta_description` TEXT,
                `robots_index` ENUM('default','index','noindex') DEFAULT 'default',
                `robots_follow` ENUM('default','follow','nofollow') DEFAULT 'default',
                `robots_advanced` VARCHAR(255),
                `canonical_url` VARCHAR(255),
                `readability_score` INT DEFAULT 0,
                `seo_score` INT DEFAULT 0,
                `schema_type` VARCHAR(50) DEFAULT 'WebPage',
                `schema_data` JSON NULL,
                `published_at` DATETIME NULL,
                `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                INDEX (`status`), INDEX (`parent_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;",

            // Services
            "CREATE TABLE IF NOT EXISTS `{$prefix}services` (
                `id` INT AUTO_INCREMENT PRIMARY KEY,
                `title` VARCHAR(255) NOT NULL,
                `slug` VARCHAR(255) NOT NULL UNIQUE,
                `short_description` TEXT,
                `content` LONGTEXT,
                `icon_class` VARCHAR(100),
                `featured_image_id` INT NULL,
                `status` ENUM('draft', 'published') DEFAULT 'draft',
                `order_index` INT DEFAULT 0,
                `price_range` VARCHAR(50),
                `focus_keyword` VARCHAR(255),
                `secondary_keywords` TEXT,
                `seo_title` VARCHAR(255),
                `meta_description` TEXT,
                `robots_index` ENUM('default','index','noindex') DEFAULT 'default',
                `robots_follow` ENUM('default','follow','nofollow') DEFAULT 'default',
                `robots_advanced` VARCHAR(255),
                `canonical_url` VARCHAR(255),
                `readability_score` INT DEFAULT 0,
                `seo_score` INT DEFAULT 0,
                `schema_type` VARCHAR(50) DEFAULT 'Service',
                `schema_data` JSON NULL,
                `published_at` DATETIME NULL,
                `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;",

            // Cities (Local SEO targets)
            "CREATE TABLE IF NOT EXISTS `{$prefix}city_pages` (
                `id` INT AUTO_INCREMENT PRIMARY KEY,
                `city_name` VARCHAR(100) NOT NULL,
                `slug` VARCHAR(100) NOT NULL UNIQUE,
                `state_province` VARCHAR(100),
                `population` VARCHAR(50),
                `latitude` DECIMAL(10,8),
                `longitude` DECIMAL(11,8),
                `content` LONGTEXT,
                `featured_image_id` INT NULL,
                `status` ENUM('draft', 'published') DEFAULT 'draft',
                `map_embed_code` TEXT,
                `focus_keyword` VARCHAR(255),
                `secondary_keywords` TEXT,
                `seo_title` VARCHAR(255),
                `meta_description` TEXT,
                `robots_index` ENUM('default','index','noindex') DEFAULT 'default',
                `robots_follow` ENUM('default','follow','nofollow') DEFAULT 'default',
                `robots_advanced` VARCHAR(255),
                `canonical_url` VARCHAR(255),
                `readability_score` INT DEFAULT 0,
                `seo_score` INT DEFAULT 0,
                `schema_type` VARCHAR(50) DEFAULT 'LocalBusiness',
                `schema_data` JSON NULL,
                `published_at` DATETIME NULL,
                `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;",

            // Categories
            "CREATE TABLE IF NOT EXISTS `{$prefix}categories` (
                `id` INT AUTO_INCREMENT PRIMARY KEY,
                `name` VARCHAR(100) NOT NULL,
                `slug` VARCHAR(100) NOT NULL UNIQUE,
                `description` TEXT,
                `parent_id` INT NULL,
                `seo_title` VARCHAR(255),
                `meta_description` TEXT,
                `focus_keyword` VARCHAR(255),
                `robots_index` ENUM('default','index','noindex') DEFAULT 'default',
                `robots_follow` ENUM('default','follow','nofollow') DEFAULT 'default',
                `canonical_url` VARCHAR(255),
                `order_index` INT DEFAULT 0,
                `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;",

            // Tags
            "CREATE TABLE IF NOT EXISTS `{$prefix}tags` (
                `id` INT AUTO_INCREMENT PRIMARY KEY,
                `name` VARCHAR(100) NOT NULL,
                `slug` VARCHAR(100) NOT NULL UNIQUE,
                `description` TEXT,
                `seo_title` VARCHAR(255),
                `meta_description` TEXT,
                `focus_keyword` VARCHAR(255),
                `robots_index` ENUM('default','index','noindex') DEFAULT 'default',
                `robots_follow` ENUM('default','follow','nofollow') DEFAULT 'default',
                `canonical_url` VARCHAR(255),
                `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;",

            // Post_Categories Pivot
            "CREATE TABLE IF NOT EXISTS `{$prefix}post_categories` (
                `post_id` INT NOT NULL,
                `category_id` INT NOT NULL,
                PRIMARY KEY (`post_id`, `category_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",

            // Post_Tags Pivot
            "CREATE TABLE IF NOT EXISTS `{$prefix}post_tags` (
                `post_id` INT NOT NULL,
                `tag_id` INT NOT NULL,
                PRIMARY KEY (`post_id`, `tag_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",

            // Case Studies
            "CREATE TABLE IF NOT EXISTS `{$prefix}case_studies` (
                `id` INT AUTO_INCREMENT PRIMARY KEY,
                `title` VARCHAR(255) NOT NULL,
                `slug` VARCHAR(255) NOT NULL UNIQUE,
                `client_name` VARCHAR(150),
                `industry` VARCHAR(100),
                `challenge` TEXT,
                `solution` TEXT,
                `results` TEXT,
                `content` LONGTEXT,
                `featured_image_id` INT NULL,
                `status` ENUM('draft', 'published') DEFAULT 'draft',
                `services_used` VARCHAR(255),
                `metrics_html` TEXT,
                `testimonial_id` INT NULL,
                `focus_keyword` VARCHAR(255),
                `secondary_keywords` TEXT,
                `seo_title` VARCHAR(255),
                `meta_description` TEXT,
                `robots_index` ENUM('default','index','noindex') DEFAULT 'default',
                `robots_follow` ENUM('default','follow','nofollow') DEFAULT 'default',
                `robots_advanced` VARCHAR(255),
                `canonical_url` VARCHAR(255),
                `readability_score` INT DEFAULT 0,
                `seo_score` INT DEFAULT 0,
                `schema_type` VARCHAR(50) DEFAULT 'Article',
                `schema_data` JSON NULL,
                `published_at` DATETIME NULL,
                `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;",

            // Testimonials
            "CREATE TABLE IF NOT EXISTS `{$prefix}testimonials` (
                `id` INT AUTO_INCREMENT PRIMARY KEY,
                `client_name` VARCHAR(100) NOT NULL,
                `designation` VARCHAR(100),
                `company` VARCHAR(100),
                `content` TEXT NOT NULL,
                `rating` INT DEFAULT 5,
                `avatar_id` INT NULL,
                `status` ENUM('draft', 'published') DEFAULT 'published',
                `order_index` INT DEFAULT 0,
                `source` VARCHAR(50) DEFAULT 'website',
                `source_url` VARCHAR(255),
                `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;",

            // Leads
            "CREATE TABLE IF NOT EXISTS `{$prefix}leads` (
                `id` INT AUTO_INCREMENT PRIMARY KEY,
                `full_name` VARCHAR(150) NOT NULL,
                `email` VARCHAR(150),
                `phone` VARCHAR(50),
                `whatsapp_number` VARCHAR(50),
                `city` VARCHAR(100),
                `service_needed` VARCHAR(100),
                `message` TEXT,
                `status` ENUM('new', 'contacted', 'qualified', 'converted', 'closed') DEFAULT 'new',
                `ip_address` VARCHAR(45),
                `user_agent` TEXT,
                `source_url` VARCHAR(255),
                `utm_source` VARCHAR(50),
                `utm_medium` VARCHAR(50),
                `utm_campaign` VARCHAR(100),
                `notes` TEXT,
                `assigned_to` INT NULL,
                `is_read` TINYINT(1) DEFAULT 0,
                `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;",

            // Redirects
            "CREATE TABLE IF NOT EXISTS `{$prefix}redirects` (
                `id` INT AUTO_INCREMENT PRIMARY KEY,
                `old_url` VARCHAR(255) NOT NULL,
                `new_url` VARCHAR(255) NOT NULL,
                `type` INT DEFAULT 301,
                `match_type` ENUM('exact','exact_ignore','contains','begins_with','regex') DEFAULT 'exact',
                `is_active` TINYINT(1) DEFAULT 1,
                `hits` INT DEFAULT 0,
                `last_accessed` DATETIME NULL,
                `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                INDEX (`old_url`), INDEX (`is_active`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;",

            // Blocked IPs
            "CREATE TABLE IF NOT EXISTS `{$prefix}blocked_ips` (
                `id` INT AUTO_INCREMENT PRIMARY KEY,
                `ip_address` VARCHAR(45) NOT NULL UNIQUE,
                `reason` VARCHAR(255),
                `attempts` INT DEFAULT 0,
                `blocked_until` DATETIME NULL,
                `is_permanent` TINYINT(1) DEFAULT 0,
                `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;",

            // Security Logs
            "CREATE TABLE IF NOT EXISTS `{$prefix}security_log` (
                `id` INT AUTO_INCREMENT PRIMARY KEY,
                `event_type` VARCHAR(50) NOT NULL,
                `user_id` INT NULL,
                `username` VARCHAR(50) NULL,
                `ip_address` VARCHAR(45) NOT NULL,
                `user_agent` TEXT,
                `request_uri` VARCHAR(255),
                `request_method` VARCHAR(10),
                `additional_data` TEXT,
                `severity` ENUM('low', 'medium', 'high', 'critical') DEFAULT 'low',
                `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",

            // Activity Logs
            "CREATE TABLE IF NOT EXISTS `{$prefix}activity_log` (
                `id` INT AUTO_INCREMENT PRIMARY KEY,
                `user_id` INT NULL,
                `action` VARCHAR(100) NOT NULL,
                `entity_type` VARCHAR(50),
                `entity_id` INT,
                `description` TEXT,
                `ip_address` VARCHAR(45),
                `user_agent` TEXT,
                `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;"
        ];

        foreach ($queries as $sql) {
            $pdo->exec($sql);
        }
    }

    private function seedData(\PDO $pdo, string $prefix, string $adminU, string $adminE, string $adminP) {
        $hash = password_hash($adminP, PASSWORD_DEFAULT);
        $pdo->exec("INSERT INTO `{$prefix}users` (username, email, password, display_name, role, seo_role, is_active)
                    VALUES ('$adminU', '$adminE', '$hash', 'Administrator', 'super_admin', 'manager', 1)");

        $settings = [
            // General
            ['general', 'site_title', 'LocalSEO.pk'],
            ['general', 'site_description', 'Top Rated Local SEO Agency in Pakistan'],
            ['general', 'site_url', 'https://localseo.pk'],
            ['general', 'timezone', 'Asia/Karachi'],
            ['general', 'admin_email', $adminE],
            ['general', 'logo_url', '/assets/images/logo.png'],
            ['general', 'favicon_url', '/assets/images/favicon.ico'],
            // Layout/Theme
            ['theme', 'primary_color', '#2563eb'],
            ['theme', 'body_font', 'Inter, sans-serif'],
            ['theme', 'heading_font', 'Inter, sans-serif'],
            // SEO LocalBusiness
            ['seo', 'seo_business_name', 'LocalSEO.pk'],
            ['seo', 'seo_business_type', 'LocalBusiness'],
            ['seo', 'seo_business_phone', '+92 300 0000000'],
            ['seo', 'seo_business_street', 'Office 123, Tech Plaza'],
            ['seo', 'seo_business_city', 'Lahore'],
            ['seo', 'seo_business_state', 'Punjab'],
            ['seo', 'seo_business_postal', '54000'],
            ['seo', 'seo_business_country', 'PK'],
            ['seo', 'seo_business_price_range', '$$$'],
            // Rank Math-style Module toggles
            ['seo', 'seo_module_404', '1'],
            ['seo', 'seo_module_acf', '0'],
            ['seo', 'seo_module_bbpress', '0'],
            ['seo', 'seo_module_buddypress', '0'],
            ['seo', 'seo_module_image_seo', '1'],
            ['seo', 'seo_module_instant_indexing', '1'],
            ['seo', 'seo_module_link_counter', '1'],
            ['seo', 'seo_module_local', '1'],
            ['seo', 'seo_module_redirections', '1'],
            ['seo', 'seo_module_schema', '1'],
            ['seo', 'seo_module_role_manager', '1'],
            ['seo', 'seo_module_sitemap', '1'],
            ['seo', 'seo_module_analytics', '1'],
            // Features
            ['security', 'login_max_attempts', '5'],
            ['security', 'login_lockout_duration', '15'],
            ['performance', 'cache_enabled', '1'],
            ['performance', 'cache_minify_html', '1'],
            ['performance', 'cache_minify_css', '1'],
            ['performance', 'cache_minify_js', '1'],
            ['performance', 'image_compression', '85'],
            ['performance', 'image_convert_to_webp', '1'],
        ];

        $stmt = $pdo->prepare("INSERT INTO `{$prefix}settings` (setting_group, setting_key, setting_value) VALUES (?, ?, ?)");
        foreach ($settings as $s) {
            $stmt->execute($s);
        }

        // Add default page
        $pdo->exec("INSERT INTO `{$prefix}pages` (author_id, title, slug, content, status, published_at)
                    VALUES (1, 'Home', 'home', '<h1>Welcome to LocalSEO.pk</h1>', 'published', NOW())");
        
        // Add sample service
        $pdo->exec("INSERT INTO `{$prefix}services` (title, slug, short_description, status, published_at)
                    VALUES ('Google Business Profile Optimization', 'gbp-optimization', 'Rank higher in Google Maps', 'published', NOW())");

        // Set homepage ID
        $pageId = $pdo->lastInsertId();
        $pdo->exec("INSERT INTO `{$prefix}settings` (setting_group, setting_key, setting_value) VALUES ('general', 'homepage_id', '$pageId')");
    }

    private function writeConfig(string $host, string $name, string $user, string $pass, string $prefix) {
        $template = file_get_contents(ROOT_PATH . '/config.php');
        $replacements = [
            "'localhost'" => "'{$host}'",
            "'localseo_db'" => "'{$name}'",
            "'root'" => "'{$user}'",
            "''" => "'{$pass}'", // careful if pass is empty, simple replacement is crude.
            "'lseo_'" => "'{$prefix}'"
        ];
        
        // Safer str_replace sequence for DB credentials
        $template = preg_replace("/define\('DB_HOST',\s*'.*?'\);/", "define('DB_HOST', '{$host}');", $template);
        $template = preg_replace("/define\('DB_NAME',\s*'.*?'\);/", "define('DB_NAME', '{$name}');", $template);
        $template = preg_replace("/define\('DB_USER',\s*'.*?'\);/", "define('DB_USER', '{$user}');", $template);
        $template = preg_replace("/define\('DB_PASS',\s*'.*?'\);/", "define('DB_PASS', '{$pass}');", $template);
        $template = preg_replace("/define\('DB_PREFIX',\s*'.*?'\);/", "define('DB_PREFIX', '{$prefix}');", $template);
        $template = preg_replace("/define\('APP_KEY',\s*'.*?'\);/", "define('APP_KEY', '" . bin2hex(random_bytes(32)) . "');", $template);

        file_put_contents(ROOT_PATH . '/config.php', $template);
    }
}

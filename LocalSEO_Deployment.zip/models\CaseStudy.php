<?php
namespace Models;
use Core\Model;

class CaseStudy extends Model {
    protected $table = 'case_studies';
    protected $fillable = [
        'title', 'slug', 'client_name', 'industry', 'challenge', 'solution', 'results',
        'content', 'featured_image_id', 'status', 'services_used',
        'metrics_html', 'testimonial_id',
        'focus_keyword', 'secondary_keywords', 'seo_title', 'meta_description',
        'robots_index', 'robots_follow', 'robots_advanced', 'canonical_url',
        'readability_score', 'seo_score', 'schema_type', 'schema_data',
        'published_at'
    ];
}

<?php ob_start(); ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="h4 mb-0"><?= $pageTitle ?></h2>
    <a href="/admin/cities/create" class="btn btn-primary"><i class="bi bi-plus-lg"></i> Add New Area Target</a>
</div>

<div class="card bg-white shadow-sm border-0 mb-4">
    <div class="card-body py-3 d-flex justify-content-between align-items-center bg-light rounded-top">
        <div class="d-flex gap-3 text-muted small">
            <span class="text-dark fw-bold">All (<?= $counts['all'] ?>)</span> | 
            <span class="text-success">Published (<?= $counts['published'] ?>)</span> | 
            <span class="text-warning">Drafts (<?= $counts['draft'] ?>)</span>
        </div>
        
        <form method="GET" action="/admin/cities" class="d-flex">
            <div class="input-group input-group-sm">
                <input type="text" name="s" class="form-control" placeholder="Search cities..." value="<?= htmlspecialchars($_GET['s'] ?? '') ?>">
                <button class="btn btn-outline-secondary" type="submit"><i class="bi bi-search"></i></button>
            </div>
        </form>
    </div>

    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead>
                <tr>
                    <th>City/Target Area</th>
                    <th>State/Province</th>
                    <th>SEO Score</th>
                    <th>Status</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <?php if(empty($cities)): ?>
                    <tr><td colspan="5" class="text-center py-5 text-muted">No city targets found.</td></tr>
                <?php else: ?>
                    <?php foreach($cities as $city): ?>
                        <tr>
                            <td>
                                <div class="fw-bold mb-1">
                                    <a href="/admin/cities/edit/<?= $city['id'] ?>" class="text-dark text-decoration-none"><?= htmlspecialchars($city['city_name']) ?></a>
                                </div>
                                <div class="small">
                                    <a href="/admin/cities/edit/<?= $city['id'] ?>" class="text-primary text-decoration-none me-2">Edit</a>
                                    <a href="/local-seo/<?= $city['slug'] ?>" target="_blank" class="text-muted text-decoration-none">View Target Page</a>
                                </div>
                            </td>
                            <td><?= htmlspecialchars($city['state_province'] ?? '--') ?></td>
                            <td>
                                <?php 
                                $s = $city['seo_score'];
                                $col = $s >= 80 ? 'success' : ($s >= 50 ? 'warning' : 'danger');
                                ?>
                                <span class="badge bg-<?= $col ?> bg-opacity-10 text-<?= $col ?> border border-<?= $col ?>"><?= $s ?>/100</span>
                            </td>
                            <td>
                                <?php if($city['status'] === 'published'): ?>
                                    <span class="badge bg-success">Published</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">Draft</span>
                                <?php endif; ?>
                            </td>
                            <td class="small text-muted">
                                <?= date('Y/m/d', strtotime($city['created_at'])) ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php if($pagination['last_page'] > 1): ?>
    <div class="card-footer bg-white py-3">
        <nav>
            <ul class="pagination pagination-sm mb-0 justify-content-end">
                <?php for($i=1; $i<=$pagination['last_page']; $i++): ?>
                    <li class="page-item <?= $i == $pagination['current'] ? 'active' : '' ?>">
                        <a class="page-link" href="?p=<?= $i ?><?= isset($_GET['s']) ? '&s='.htmlspecialchars($_GET['s']) : '' ?>"><?= $i ?></a>
                    </li>
                <?php endfor; ?>
            </ul>
        </nav>
    </div>
    <?php endif; ?>
</div>

<?php 
$content = ob_get_clean();
require dirname(__DIR__) . '/_layout.php';
?>

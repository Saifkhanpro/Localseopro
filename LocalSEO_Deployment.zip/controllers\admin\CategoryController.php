<?php
namespace Controllers\Admin;
use Core\Controller;
use Core\Helpers;
use Models\Category;

class CategoryController extends Controller {
    public function index() {
        $this->requireRole(['super_admin', 'admin', 'editor']);
        
        $catModel = new Category();
        $categories = $catModel->getTree();

        $this->adminView('categories/index', [
            'pageTitle' => 'Categories',
            'categories' => $categories
        ]);
    }

    public function save() {
        $this->requireRole(['super_admin', 'admin', 'editor']);
        $this->verifyCsrf();

        $id = (int)$this->input('id', 0);
        $catModel = new Category();

        $name = $this->input('name');
        if (empty($name)) {
            Helpers::flash('error', 'Category name is required.');
            $this->redirect('/admin/categories');
            return;
        }

        $slug = Helpers::generateUniqueSlug($this->input('slug') ?: $name, 'categories', $id);
        $parentId = (int)$this->input('parent_id') ?: null;
        if ($parentId === $id) $parentId = null;

        $data = [
            'name' => $name,
            'slug' => $slug,
            'description' => $this->input('description', ''),
            'parent_id' => $parentId,
            'seo_title' => $this->input('seo_title', ''),
            'meta_description' => $this->input('meta_description', ''),
            'focus_keyword' => $this->input('focus_keyword', ''),
            'robots_index' => $this->input('robots_index', 'default'),
            'robots_follow' => $this->input('robots_follow', 'default'),
            'canonical_url' => $this->input('canonical_url', ''),
            'order_index' => (int)$this->input('order_index', 0)
        ];

        if ($id > 0) {
            $catModel->update($id, $data);
            Helpers::flash('success', 'Category updated successfully.');
        } else {
            $catModel->create($data);
            Helpers::flash('success', 'Category created successfully.');
        }

        $cm = new \Core\CacheMonitor();
        $cm->clearType('pages');
        $this->redirect('/admin/categories');
    }

    public function delete(int $id) {
        $this->requireRole(['super_admin', 'admin', 'editor']);
        $catModel = new Category();
        $db = \Core\Database::getInstance();
        
        $cat = $catModel->find($id);
        if ($cat) {
            // Unset parent_id for children
            $db->update($db->t('categories'), ['parent_id' => null], 'parent_id=?', [$id]);
            // Remove from pivots
            $db->delete($db->t('post_categories'), 'category_id=?', [$id]);
            // Delete category
            $catModel->delete($id);
            Helpers::flash('success', 'Category deleted successfully.');
            
            $cm = new \Core\CacheMonitor();
            $cm->clearType('pages');
        }
        $this->redirect('/admin/categories');
    }
}

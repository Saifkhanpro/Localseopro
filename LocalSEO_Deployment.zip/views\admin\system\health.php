<?php ob_start(); ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="h4 mb-0"><i class="bi bi-heart-pulse text-danger me-2"></i> <?= $pageTitle ?></h2>
    <button onclick="window.location.reload();" class="btn btn-outline-secondary"><i class="bi bi-arrow-clockwise"></i> Run Check Again</button>
</div>

<!-- Score Card -->
<div class="card border-0 shadow-sm mb-4">
    <div class="card-body p-5 text-center bg-light rounded">
        <?php 
        $score = $report['score'];
        $col = $score >= 80 ? 'success' : ($score >= 50 ? 'warning' : 'danger');
        $msg = $score >= 80 ? 'Excellent' : ($score >= 50 ? 'Needs Attention' : 'Critical Issues Found');
        ?>
        <div class="position-relative d-inline-block mb-3">
            <svg viewBox="0 0 36 36" class="circular-chart text-<?= $col ?>" style="width: 150px; height: 150px; stroke: currentColor; fill: none; stroke-width: 3;">
                <path d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" style="stroke: #eee;" />
                <path d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" style="stroke-dasharray: <?= $score ?>, 100;" />
            </svg>
            <div class="position-absolute top-50 start-50 translate-middle h1 fw-bold text-dark mb-0"><?= $score ?>%</div>
        </div>
        <h3 class="fw-bold text-<?= $col ?>"><?= $msg ?></h3>
        <p class="text-muted w-50 mx-auto">This score indicates the technical health, security status, and performance readiness of the SEO CMS infrastructure.</p>
    </div>
</div>

<div class="row g-4">
    <!-- Server Environment Check -->
    <div class="col-lg-6">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-header bg-white fw-bold py-3"><i class="bi bi-server me-2"></i> Environment Checks</div>
            <ul class="list-group list-group-flush">
                <?php foreach($report['env'] as $chk => $data): ?>
                    <li class="list-group-item d-flex justify-content-between align-items-center p-3">
                        <div>
                            <div class="fw-bold text-dark"><?= htmlspecialchars($chk) ?></div>
                            <div class="small text-muted font-monospace"><?= htmlspecialchars($data['val']) ?></div>
                        </div>
                        <?php if($data['status'] === 'ok'): ?>
                            <span class="badge bg-success rounded-pill"><i class="bi bi-check-lg"></i> OK</span>
                        <?php else: ?>
                            <span class="badge bg-danger rounded-pill"><i class="bi bi-exclamation-triangle"></i> FIX</span>
                        <?php endif; ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>

    <!-- Security & Cache Check -->
    <div class="col-lg-6">
        <div class="card border-0 shadow-sm h-100 mb-4">
            <div class="card-header bg-white fw-bold py-3"><i class="bi bi-shield-check me-2"></i> Security & Performance</div>
            <ul class="list-group list-group-flush">
                <?php foreach($report['security'] as $chk => $data): ?>
                    <li class="list-group-item d-flex justify-content-between align-items-center p-3">
                        <div>
                            <div class="fw-bold text-dark"><?= htmlspecialchars($chk) ?></div>
                        </div>
                        <?php if($data['status'] === 'ok'): ?>
                            <span class="text-success"><i class="bi bi-check-circle-fill fs-5"></i></span>
                        <?php else: ?>
                            <span class="text-danger" title="<?= htmlspecialchars($data['msg']) ?>"><i class="bi bi-x-circle-fill fs-5"></i></span>
                        <?php endif; ?>
                    </li>
                <?php endforeach; ?>
                <?php foreach($report['cache'] as $chk => $data): ?>
                    <li class="list-group-item d-flex justify-content-between align-items-center p-3 bg-light">
                        <div>
                            <div class="fw-bold pt-1"><i class="bi bi-lightning-charge text-warning"></i> <?= htmlspecialchars($chk) ?></div>
                        </div>
                        <?php if($data['status'] === 'ok'): ?>
                            <span class="badge bg-success">Active</span>
                        <?php else: ?>
                            <span class="badge bg-secondary">Disabled</span>
                        <?php endif; ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
</div>

<?php 
$content = ob_get_clean();
require dirname(__DIR__) . '/_layout.php';
?>

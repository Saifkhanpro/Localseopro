<?php ob_start(); ?>

<form method="POST" action="/admin/cities/save">
    <input type="hidden" name="csrf_token" value="<?= \Core\CSRF::generate() ?>">
    <input type="hidden" name="id" value="<?= $city['id'] ?? 0 ?>">
    
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="h4 mb-0"><?= $pageTitle ?></h2>
        <button type="submit" class="btn btn-primary"><i class="bi bi-save me-1"></i> Save City Page</button>
    </div>

    <div class="row g-4">
        <div class="col-lg-8">
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-body">
                    <div class="mb-4">
                        <label class="form-label fw-bold">City/Area Name</label>
                        <input type="text" name="city_name" class="form-control form-control-lg" required value="<?= htmlspecialchars($city['city_name'] ?? '') ?>" placeholder="e.g. Lahore">
                        <?php if(isset($city['slug'])): ?>
                            <div class="form-text mt-2"><i class="bi bi-link-45deg"></i> Permalink: <strong><?= rtrim(APP_URL, '/') ?>/local-seo/<?= htmlspecialchars($city['slug']) ?></strong></div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <label class="form-label fw-bold">State / Province</label>
                            <input type="text" name="state_province" class="form-control" value="<?= htmlspecialchars($city['state_province'] ?? '') ?>" placeholder="e.g. Punjab">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Population Target</label>
                            <input type="text" name="population" class="form-control" value="<?= htmlspecialchars($city['population'] ?? '') ?>" placeholder="e.g. 13 Million">
                        </div>
                    </div>

                    <div class="mb-4">
                        <label class="form-label fw-bold">Localized Content Strategy</label>
                        <textarea name="content" class="wysiwyg form-control"><?= htmlspecialchars($city['content'] ?? '') ?></textarea>
                    </div>

                    <div class="mb-4">
                        <label class="form-label fw-bold text-danger"><i class="bi bi-pin-map-fill me-1"></i> Map Embed Code (iFrame)</label>
                        <textarea name="map_embed_code" class="form-control" rows="4" placeholder="<iframe src='...' width='600' height='450' style='border:0;' allowfullscreen='' loading='lazy'></iframe>"><?= htmlspecialchars($city['map_embed_code'] ?? '') ?></textarea>
                        <div class="form-text">Paste the HTML iframe embed code generated directly from Google Maps. It drastically improves Local SEO.</div>
                    </div>
                </div>
            </div>

            <div class="card border-0 shadow-sm mb-4 border-top border-primary border-3">
                <div class="card-header bg-white">
                    <h5 class="mb-0 text-primary"><i class="bi bi-search me-2"></i> Area SEO Parameters</h5>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Focus Keyword</label>
                        <input type="text" name="focus_keyword" class="form-control" value="<?= htmlspecialchars($city['focus_keyword'] ?? '') ?>" placeholder="e.g. Local SEO Agency in Lahore">
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label fw-bold">SEO Title</label>
                        <input type="text" name="seo_title" class="form-control" value="<?= htmlspecialchars($city['seo_title'] ?? '') ?>">
                        <div class="form-text">If blank, defaults to 'Local SEO Expert in {City}'</div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Meta Description</label>
                        <textarea name="meta_description" class="form-control" rows="3"><?= htmlspecialchars($city['meta_description'] ?? '') ?></textarea>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-white fw-bold">Publishing & Meta</div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label text-muted small fw-bold">Status</label>
                        <select name="status" class="form-select">
                            <option value="draft" <?= ($city['status'] ?? 'draft') === 'draft' ? 'selected' : '' ?>>Draft</option>
                            <option value="published" <?= ($city['status'] ?? '') === 'published' ? 'selected' : '' ?>>Published</option>
                        </select>
                    </div>
                    
                    <hr>
                    <label class="form-label text-muted small fw-bold mb-2">Coordinates (Optional, for precise Schema)</label>
                    <div class="mb-3">
                        <label class="form-label small">Latitude</label>
                        <input type="number" step="any" name="latitude" class="form-control" value="<?= $city['latitude'] ?? '' ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label small">Longitude</label>
                        <input type="number" step="any" name="longitude" class="form-control" value="<?= $city['longitude'] ?? '' ?>">
                    </div>
                </div>
                <div class="card-footer bg-light text-end">
                    <button type="submit" class="btn btn-primary w-100">Save City Page</button>
                </div>
            </div>

            <div class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-white fw-bold">Hero / Skyline Image</div>
                <div class="card-body text-center">
                    <input type="hidden" name="featured_image_id" id="featured_image_id" value="<?= $city['featured_image_id'] ?? '' ?>">
                    <div id="image-preview" class="mb-3 <?= empty($featuredImageUrl) ? 'd-none' : '' ?>">
                        <img src="<?= htmlspecialchars($featuredImageUrl ?? '') ?>" class="img-fluid rounded border">
                    </div>
                    <button type="button" class="btn btn-outline-secondary w-100" onclick="alert('Media Selection');"><i class="bi bi-image"></i> Set Image</button>
                </div>
            </div>
        </div>
    </div>
</form>

<?php 
$content = ob_get_clean();
require dirname(__DIR__) . '/_layout.php';
?>

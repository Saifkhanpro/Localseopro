<?php
namespace Controllers\Admin;
use Core\Controller;
use Core\Helpers;
use Models\Setting;

class SettingController extends Controller {
    public function index() {
        $this->requireRole(['super_admin', 'admin']);
        
        $settingModel = new Setting();
        $groupedSettings = $settingModel->getAllGrouped();

        $this->adminView('settings/index', [
            'pageTitle' => 'Global Settings',
            'settings' => $groupedSettings
        ]);
    }

    public function save() {
        $this->requireRole(['super_admin', 'admin']);
        $this->verifyCsrf();

        $settingModel = new Setting();
        $group = $this->input('group', 'general');
        $settings = $_POST['settings'] ?? [];

        foreach ($settings as $key => $value) {
            $settingModel->set($key, $value, $group, true);
        }

        // Feature Toggles (Checkboxes often aren't passed if unchecked)
        $toggles = [
            'performance' => ['cache_enabled', 'cache_minify_html', 'cache_minify_css', 'cache_minify_js', 'image_auto_optimize', 'image_convert_to_webp'],
            'seo' => [
                'seo_module_404', 'seo_module_acf', 'seo_module_bbpress', 'seo_module_buddypress',
                'seo_module_image_seo', 'seo_module_instant_indexing', 'seo_module_link_counter',
                'seo_module_local', 'seo_module_redirections', 'seo_module_schema',
                'seo_module_role_manager', 'seo_module_sitemap', 'seo_module_analytics'
            ]
        ];

        if (isset($toggles[$group])) {
            foreach ($toggles[$group] as $toggleKey) {
                $val = isset($settings[$toggleKey]) ? '1' : '0';
                $settingModel->set($toggleKey, $val, $group, true);
            }
        }

        // Cache clears
        $cm = new \Core\CacheMonitor();
        $cm->clearType('objects');
        if ($group === 'performance') $cm->clearType('pages');

        Helpers::flash('success', 'Settings updated successfully.');
        $this->redirect('/admin/settings?group=' . $group);
    }
}

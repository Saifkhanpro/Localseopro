<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle ?? 'Admin') ?> - LocalSEO.pk</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <style>
        :root { --admin-bg: #f3f4f6; --admin-sidebar: #111827; --admin-primary: #2563eb; }
        body { background-color: var(--admin-bg); font-family: 'Inter', system-ui, sans-serif; overflow-x: hidden; }
        #wrapper { display: flex; width: 100vw; height: 100vh; overflow: hidden; }
        
        #sidebar { width: 260px; background: var(--admin-sidebar); color: #9ca3af; display: flex; flex-direction: column; flex-shrink: 0; overflow-y: auto; }
        #sidebar .brand { padding: 1.5rem; font-size: 1.25rem; font-weight: 700; color: white; border-bottom: 1px solid rgba(255,255,255,0.1); letter-spacing: -0.5px; }
        #sidebar .nav-list { padding: 1rem 0; list-style: none; margin: 0; }
        #sidebar .nav-item { padding: 0.25rem 1rem; }
        #sidebar .nav-link { color: #d1d5db; text-decoration: none; padding: 0.6rem 1rem; border-radius: 6px; display: flex; align-items: center; gap: 0.75rem; font-size: 0.9rem; font-weight: 500; transition: all 0.2s; }
        #sidebar .nav-link:hover, #sidebar .nav-link.active { background: rgba(255,255,255,0.1); color: white; }
        #sidebar .nav-link i { font-size: 1.1rem; width: 20px; text-align: center; }
        #sidebar .nav-section { font-size: 0.75rem; text-transform: uppercase; color: #6b7280; font-weight: 700; padding: 1.5rem 1.5rem 0.5rem; letter-spacing: 0.5px; }
        
        #main-content { flex-grow: 1; display: flex; flex-direction: column; overflow: hidden; }
        #topbar { background: white; height: 64px; box-shadow: 0 1px 3px rgba(0,0,0,0.05); display: flex; align-items: center; justify-content: space-between; padding: 0 2rem; z-index: 10; flex-shrink: 0; }
        #page-content { flex-grow: 1; overflow-y: auto; padding: 2rem; }
        
        .card { border: none; box-shadow: 0 1px 3px rgba(0,0,0,0.05), 0 1px 2px rgba(0,0,0,0.025); border-radius: 8px; margin-bottom: 1.5rem; }
        .card-header { background: white; border-bottom: 1px solid #f3f4f6; padding: 1.25rem 1.5rem; font-weight: 600; border-radius: 8px 8px 0 0 !important; }
        .table th { background: #f9fafb; font-weight: 600; font-size: 0.85rem; text-transform: uppercase; color: #6b7280; letter-spacing: 0.5px; border-bottom: 2px solid #e5e7eb; }
        .table td { vertical-align: middle; padding: 1rem; font-size: 0.9rem; }
        
        .btn-primary { background: var(--admin-primary); border-color: var(--admin-primary); }
        .btn-sm { padding: 0.4rem 0.8rem; font-size: 0.8rem; }
        .badge { font-weight: 500; padding: 0.4em 0.8em; }
    </style>
</head>
<body>

<div id="wrapper">
    <!-- Sidebar -->
    <aside id="sidebar">
        <div class="brand">
            <i class="bi bi-speedometer2 me-2 text-primary"></i> LocalSEO.pk
        </div>
        
        <ul class="nav-list">
            <li class="nav-item">
                <a href="/admin/dashboard" class="nav-link <?= strpos($_SERVER['REQUEST_URI'], '/admin/dashboard') === 0 ? 'active' : '' ?>">
                    <i class="bi bi-grid-1x2"></i> Dashboard
                </a>
            </li>
            
            <div class="nav-section">CRM & Leads</div>
            <li class="nav-item">
                <a href="/admin/leads" class="nav-link <?= strpos($_SERVER['REQUEST_URI'], '/admin/leads') === 0 ? 'active' : '' ?>">
                    <i class="bi bi-inbox"></i> Leads Inbox
                </a>
            </li>

            <div class="nav-section">Content Management</div>
            <li class="nav-item">
                <a href="/admin/posts" class="nav-link <?= strpos($_SERVER['REQUEST_URI'], '/admin/posts') === 0 ? 'active' : '' ?>">
                    <i class="bi bi-file-earmark-text"></i> Blog Posts
                </a>
            </li>
            <li class="nav-item">
                <a href="/admin/pages" class="nav-link <?= strpos($_SERVER['REQUEST_URI'], '/admin/pages') === 0 ? 'active' : '' ?>">
                    <i class="bi bi-files"></i> Pages
                </a>
            </li>
            <li class="nav-item">
                <a href="/admin/services" class="nav-link <?= strpos($_SERVER['REQUEST_URI'], '/admin/services') === 0 ? 'active' : '' ?>">
                    <i class="bi bi-briefcase"></i> Services
                </a>
            </li>
            <li class="nav-item">
                <a href="/admin/cities" class="nav-link <?= strpos($_SERVER['REQUEST_URI'], '/admin/cities') === 0 ? 'active' : '' ?>">
                    <i class="bi bi-geo-alt"></i> City Targets
                </a>
            </li>
            <li class="nav-item">
                <a href="/admin/categories" class="nav-link <?= strpos($_SERVER['REQUEST_URI'], '/admin/categories') === 0 ? 'active' : '' ?>">
                    <i class="bi bi-tags"></i> Categories
                </a>
            </li>
            <li class="nav-item">
                <a href="/admin/media" class="nav-link <?= strpos($_SERVER['REQUEST_URI'], '/admin/media') === 0 ? 'active' : '' ?>">
                    <i class="bi bi-images"></i> Media Library
                </a>
            </li>

            <div class="nav-section">SEO & Tools</div>
            <li class="nav-item">
                <a href="/admin/seo/auto-links" class="nav-link <?= strpos($_SERVER['REQUEST_URI'], '/admin/seo/auto-links') === 0 ? 'active' : '' ?>">
                    <i class="bi bi-link-45deg"></i> Auto Links
                </a>
            </li>
            <li class="nav-item">
                <a href="/admin/seo/redirects" class="nav-link <?= strpos($_SERVER['REQUEST_URI'], '/admin/seo/redirects') === 0 ? 'active' : '' ?>">
                    <i class="bi bi-arrow-left-right"></i> 301 Redirects
                </a>
            </li>

            <div class="nav-section">System</div>
            <li class="nav-item">
                <a href="/admin/users" class="nav-link <?= strpos($_SERVER['REQUEST_URI'], '/admin/users') === 0 ? 'active' : '' ?>">
                    <i class="bi bi-people"></i> Users
                </a>
            </li>
            <li class="nav-item">
                <a href="/admin/menus" class="nav-link <?= strpos($_SERVER['REQUEST_URI'], '/admin/menus') === 0 ? 'active' : '' ?>">
                    <i class="bi bi-menu-button-wide"></i> Menus
                </a>
            </li>
            <li class="nav-item">
                <a href="/admin/settings" class="nav-link <?= strpos($_SERVER['REQUEST_URI'], '/admin/settings') === 0 ? 'active' : '' ?>">
                    <i class="bi bi-gear"></i> Settings
                </a>
            </li>
            <li class="nav-item">
                <a href="/admin/system/health" class="nav-link <?= strpos($_SERVER['REQUEST_URI'], '/admin/system/health') === 0 ? 'active' : '' ?>">
                    <i class="bi bi-heart-pulse"></i> Site Health
                </a>
            </li>
            <li class="nav-item">
                <a href="/admin/system/updates" class="nav-link <?= strpos($_SERVER['REQUEST_URI'], '/admin/system/updates') === 0 ? 'active' : '' ?>">
                    <i class="bi bi-cloud-arrow-down"></i> Updates
                </a>
            </li>
        </ul>
    </aside>

    <!-- Main Content -->
    <div id="main-content">
        <!-- Topbar -->
        <header id="topbar">
            <div class="d-flex align-items-center">
                <h5 class="mb-0 fw-bold"><?= htmlspecialchars($pageTitle ?? 'Dashboard') ?></h5>
                <a href="/" target="_blank" class="ms-4 text-muted text-decoration-none small"><i class="bi bi-box-arrow-up-right"></i> View Site</a>
            </div>
            <div class="d-flex align-items-center gap-3">
                <div class="dropdown">
                    <a href="#" class="text-dark text-decoration-none dropdown-toggle fw-semibold" data-bs-toggle="dropdown">
                        <i class="bi bi-person-circle fs-5 me-1 text-primary"></i> 
                        <?= htmlspecialchars($this->auth->user()['display_name'] ?? 'Admin') ?>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end shadow-sm border-0">
                        <li><a class="dropdown-item" href="/admin/users/edit/<?= $this->auth->user()['id'] ?>">Edit Profile</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item text-danger" href="/admin/logout">Sign Out</a></li>
                    </ul>
                </div>
            </div>
        </header>

        <!-- Page Content -->
        <main id="page-content">
            <?php if (isset($_SESSION['flash_success'])): ?>
                <div class="alert alert-success alert-dismissible fade show shadow-sm border-0">
                    <i class="bi bi-check-circle-fill me-2"></i> <?= htmlspecialchars($_SESSION['flash_success']) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
                <?php unset($_SESSION['flash_success']); ?>
            <?php endif; ?>

            <?php if (isset($_SESSION['flash_error'])): ?>
                <div class="alert alert-danger alert-dismissible fade show shadow-sm border-0">
                    <i class="bi bi-exclamation-triangle-fill me-2"></i> <?= htmlspecialchars($_SESSION['flash_error']) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
                <?php unset($_SESSION['flash_error']); ?>
            <?php endif; ?>

            <!-- View content injected here -->
            <?= $content ?>
        </main>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.tiny.cloud/1/no-api-key/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>
<script>
    // Initialize standard WYSIWYG
    tinymce.init({
        selector: '.wysiwyg',
        plugins: 'advlist autolink lists link image charmap preview anchor pagebreak searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking table emoticons template help',
        toolbar: 'undo redo | blocks fontfamily fontsize | bold italic underline strikethrough | link image media table | align lineheight | numlist bullist indent outdent | emoticons charmap | removeformat | code',
        menubar: true,
        height: 500,
        branding: false,
        promotion: false
    });
</script>
</body>
</html>

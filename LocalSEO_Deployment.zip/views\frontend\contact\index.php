<?php ob_start(); ?>

<div class="bg-primary py-5 text-white position-relative overflow-hidden border-bottom text-center">
    <div class="position-absolute align-items-center justify-content-center w-100 h-100 d-flex pe-none opacity-10" style="top:0; left:0;">
        <i class="bi bi-envelope-paper-fill" style="font-size: 25rem;"></i>
    </div>
    <div class="container py-4 position-relative z-1">
        <h1 class="display-4 fw-bolder mb-3 text-white">Contact Us</h1>
        <p class="lead text-white-50 max-w-700 mx-auto mb-0">Ready to outrank your competitors? Request your free SEO audit or ask us any questions about our services.</p>
    </div>
</div>

<div class="container py-5 my-md-4">
    <div class="row g-5">
        <!-- Contact Form Side -->
        <div class="col-lg-7">
            <div class="bg-white p-4 p-md-5 rounded-4 shadow-sm border h-100">
                <h2 class="fw-bold h3 mb-2">Request a Free Audit</h2>
                <p class="text-muted mb-4">Fill out the form below and our SEO strategists will analyze your website and get back to you within 24 hours.</p>
                
                <?php if ($errors = $_SESSION['form_errors'] ?? null): ?>
                    <div class="alert alert-danger rounded-3 mb-4">
                        <ul class="mb-0">
                            <?php foreach ($errors as $e): ?>
                                <li><?= \Core\Helpers::escape($e) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                    <?php unset($_SESSION['form_errors']); ?>
                <?php endif; ?>

                <?php 
                    $fd = $_SESSION['form_data'] ?? [];
                    unset($_SESSION['form_data']);
                    $prefilledService = $_GET['service'] ?? '';
                    $prefilledCity = $_GET['city'] ?? '';
                ?>

                <form action="/contact" method="POST" id="contactForm">
                    <input type="hidden" name="csrf_token" value="<?= \Core\CSRF::generate() ?>">
                    <!-- Honeypot -->
                    <div style="display:none;"><input type="text" name="website_url_hp" value=""></div>
                    
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small text-muted">Full Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control bg-light py-2 px-3 border-0" name="full_name" value="<?= \Core\Helpers::escape($fd['full_name'] ?? '') ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small text-muted">Email Address <span class="text-danger">*</span></label>
                            <input type="email" class="form-control bg-light py-2 px-3 border-0" name="email" value="<?= \Core\Helpers::escape($fd['email'] ?? '') ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small text-muted">Phone Number <span class="text-danger">*</span></label>
                            <input type="tel" class="form-control bg-light py-2 px-3 border-0" name="phone" value="<?= \Core\Helpers::escape($fd['phone'] ?? '') ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small text-muted">WhatsApp Number (Optional)</label>
                            <input type="tel" class="form-control bg-light py-2 px-3 border-0" name="whatsapp_number" value="<?= \Core\Helpers::escape($fd['whatsapp_number'] ?? '') ?>">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small text-muted">City/Location</label>
                            <input type="text" class="form-control bg-light py-2 px-3 border-0" name="city" value="<?= \Core\Helpers::escape($fd['city'] ?? $prefilledCity) ?>">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small text-muted">Service Interested In <span class="text-danger">*</span></label>
                            <select class="form-select bg-light py-2 px-3 border-0" name="service_needed" required>
                                <option value="" disabled <?= empty($fd['service_needed']) && empty($prefilledService) ? 'selected' : '' ?>>Select a service...</option>
                                <option value="Local SEO" <?= ($fd['service_needed'] ?? $prefilledService) == 'Local SEO' ? 'selected' : '' ?>>Local SEO</option>
                                <option value="Google Business Profile Optimization" <?= ($fd['service_needed'] ?? $prefilledService) == 'Google Business Profile Optimization' ? 'selected' : '' ?>>Google Business Profile</option>
                                <option value="Keyword Research" <?= ($fd['service_needed'] ?? '') == 'Keyword Research' ? 'selected' : '' ?>>Keyword Research</option>
                                <option value="SEO Audit" <?= ($fd['service_needed'] ?? '') == 'SEO Audit' ? 'selected' : '' ?>>Comprehensive SEO Audit</option>
                                <option value="Other" <?= ($fd['service_needed'] ?? '') == 'Other' ? 'selected' : '' ?>>Other / General Inquiry</option>
                            </select>
                        </div>
                        <div class="col-12">
                            <label class="form-label fw-semibold small text-muted">Website URL & Project Details <span class="text-danger">*</span></label>
                            <textarea class="form-control bg-light py-2 px-3 border-0" name="message" rows="5" placeholder="Please share your website URL and what you are looking to achieve..." required><?= \Core\Helpers::escape($fd['message'] ?? '') ?></textarea>
                        </div>
                        <div class="col-12 mt-4">
                            <button type="submit" class="btn btn-primary btn-lg rounded-pill px-5 fw-bold w-100 py-3 shadow-sm">
                                Send Message & Request Audit
                            </button>
                            <p class="text-center text-muted small mt-3 mb-0"><i class="bi bi-lock-fill me-1"></i> Your information is secure and will never be shared.</p>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Contact Info Side -->
        <div class="col-lg-5">
            <div class="card border-0 shadow-sm rounded-4 mb-4 bg-light overflow-hidden">
                <div class="card-body p-4 p-md-5">
                    <h3 class="fw-bold h4 mb-4">Contact Information</h3>
                    
                    <div class="d-flex mb-4 align-items-center">
                        <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center flex-shrink-0 shadow-sm" style="width: 50px; height: 50px;">
                            <i class="bi bi-geo-alt-fill fs-5"></i>
                        </div>
                        <div class="ms-4">
                            <span class="d-block text-muted small fw-bold text-uppercase tracking-wide mb-1">Office Location</span>
                            <span class="fs-6 fw-medium text-dark lh-sm d-block"><?= \Core\Helpers::escape($business_address) ?></span>
                        </div>
                    </div>

                    <div class="d-flex mb-4 align-items-center">
                        <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center flex-shrink-0 shadow-sm" style="width: 50px; height: 50px;">
                            <i class="bi bi-telephone-fill fs-5"></i>
                        </div>
                        <div class="ms-4">
                            <span class="d-block text-muted small fw-bold text-uppercase tracking-wide mb-1">Phone Number</span>
                            <a href="tel:<?= \Core\Helpers::escape(str_replace(' ', '', $business_phone)) ?>" class="fs-6 fw-medium text-dark text-decoration-none hover-primary"><?= \Core\Helpers::escape($business_phone) ?></a>
                        </div>
                    </div>

                    <div class="d-flex mb-4 align-items-center">
                        <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center flex-shrink-0 shadow-sm" style="width: 50px; height: 50px;">
                            <i class="bi bi-envelope-fill fs-5"></i>
                        </div>
                        <div class="ms-4">
                            <span class="d-block text-muted small fw-bold text-uppercase tracking-wide mb-1">Email Address</span>
                            <a href="mailto:<?= \Core\Helpers::escape($business_email) ?>" class="fs-6 fw-medium text-dark text-decoration-none hover-primary"><?= \Core\Helpers::escape($business_email) ?></a>
                        </div>
                    </div>

                    <div class="d-flex align-items-center">
                        <div class="bg-success text-white rounded-circle d-flex align-items-center justify-content-center flex-shrink-0 shadow-sm" style="width: 50px; height: 50px;">
                            <i class="bi bi-whatsapp fs-5"></i>
                        </div>
                        <div class="ms-4">
                            <span class="d-block text-muted small fw-bold text-uppercase tracking-wide mb-1">WhatsApp Chat</span>
                            <a href="https://wa.me/<?= str_replace(['+', ' ', '-'], '', $business_phone) ?>" target="_blank" class="fs-6 fw-medium text-success text-decoration-none fw-bold">Chat with us now</a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Optional Maps Embed if available -->
            <?php if (!empty($maps_embed)): ?>
            <div class="card border-0 shadow-sm rounded-4 overflow-hidden mt-4">
                <div class="ratio ratio-16x9">
                    <?= $maps_embed ?>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<style>
    .max-w-700 { max-width: 700px; }
    .tracking-wide { letter-spacing: 0.05em; }
    .hover-primary:hover { color: var(--primary-color)!important; transition: color 0.2s ease; }
    .ratio-16x9 iframe { width: 100%!important; height: 100%!important; border: 0;}
    /* Input focus styling */
    .form-control:focus, .form-select:focus {
        background-color: #fff!important;
        border-color: var(--primary-color)!important;
        box-shadow: 0 0 0 0.25rem rgba(37, 99, 235, 0.15)!important;
    }
</style>

<?php
$content = ob_get_clean();
require VIEW_PATH . '/frontend/_layout.php';
?>

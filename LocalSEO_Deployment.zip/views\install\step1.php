<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LocalSEO.pk - Installation Wizard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <style>
        body { background-color: #f8f9fa; font-family: 'Inter', sans-serif; }
        .install-card { max-width: 800px; margin: 40px auto; border: none; border-radius: 12px; box-shadow: 0 10px 30px rgba(0,0,0,0.05); }
        .logo-placeholder { width: 80px; height: 80px; background: #2563eb; color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 2rem; margin: 0 auto 20px; font-weight: bold; }
    </style>
</head>
<body>

<div class="container">
    <div class="card install-card">
        <div class="card-body p-5">
            <div class="text-center mb-5">
                <div class="logo-placeholder"><i class="bi bi-rocket-takeoff"></i></div>
                <h1 class="h3 fw-bold">LocalSEO.pk Installation</h1>
                <p class="text-muted">Welcome to the enterprise local SEO platform setup.</p>
            </div>

            <?php if (!$allGood): ?>
                <div class="alert alert-danger mb-4">
                    <h5 class="alert-heading"><i class="bi bi-exclamation-triangle-fill me-2"></i> System Requirements Not Met</h5>
                    <p class="mb-0">Please resolve the following issues before continuing:</p>
                    <ul class="mb-0 mt-2">
                        <?php foreach ($checks as $name => $passed): ?>
                            <?php if (!$passed): ?>
                                <li><strong><?= ucfirst($name) ?>:</strong> Failed</li>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <div class="text-center">
                    <a href="" class="btn btn-primary px-4">Retry Checks</a>
                </div>
            <?php else: ?>
                <div class="alert alert-success mb-4">
                    <i class="bi bi-check-circle-fill me-2"></i> All system requirements are met. You can proceed with the installation.
                </div>

                <form method="POST" action="/install.php/process">
                    <div class="row g-4">
                        <div class="col-md-6">
                            <h5 class="mb-3 border-bottom pb-2">Database Setup</h5>
                            <div class="mb-3">
                                <label class="form-label">Database Host</label>
                                <input type="text" name="db_host" class="form-control" value="localhost" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Database Name</label>
                                <input type="text" name="db_name" class="form-control" placeholder="localseo_db" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Database Username</label>
                                <input type="text" name="db_user" class="form-control" placeholder="root" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Database Password</label>
                                <input type="password" name="db_pass" class="form-control">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Table Prefix</label>
                                <input type="text" name="db_prefix" class="form-control" value="lseo_" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <h5 class="mb-3 border-bottom pb-2">Admin Account</h5>
                            <div class="mb-3">
                                <label class="form-label">Admin Username</label>
                                <input type="text" name="admin_user" class="form-control" value="admin" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Admin Email</label>
                                <input type="email" name="admin_email" class="form-control" placeholder="admin@example.com" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Admin Password</label>
                                <input type="password" name="admin_pass" class="form-control" required>
                            </div>
                            
                            <div class="mt-5 text-end">
                                <button type="submit" class="btn btn-primary btn-lg px-5">Install LocalSEO <i class="bi bi-arrow-right ms-2"></i></button>
                            </div>
                        </div>
                    </div>
                </form>
            <?php endif; ?>
        </div>
    </div>
</div>

</body>
</html>

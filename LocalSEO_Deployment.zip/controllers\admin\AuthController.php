<?php
namespace Controllers\Admin;
use Core\Controller;

class AuthController extends Controller {
    public function login() {
        if ($this->auth->check()) {
            $this->redirect(trim(APP_URL, '/') . '/admin/dashboard');
            return;
        }
        
        // Simple standalone view for login
        require VIEW_PATH . '/admin/login.php';
    }

    public function processLogin() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') $this->redirect('/admin/login');
        
        $this->verifyCsrf();
        $username = $this->input('username');
        $password = $this->input('password');

        if (empty($username) || empty($password)) {
            \Core\Helpers::flash('error', 'Username and password are required.');
            $this->redirect('/admin/login');
            return;
        }

        $result = $this->auth->attempt($username, $password);

        if ($result['success']) {
            $this->redirect(trim(APP_URL, '/') . '/admin/dashboard');
        } else {
            \Core\Helpers::flash('error', $result['error']);
            $this->redirect('/admin/login');
        }
    }

    public function logout() {
        $this->auth->logout();
        \Core\Helpers::flash('success', 'You have been logged out safely.');
        $this->redirect('/admin/login');
    }
}

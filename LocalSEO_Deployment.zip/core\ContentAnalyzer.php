<?php
namespace Core;

class ContentAnalyzer {
    public function calculateGrade(string $content): string {
        $text = strip_tags($content);
        $sentences = max(1, preg_match_all('/[.!?]+/', $text, $matches));
        $words = max(1, str_word_count($text));
        $syllables = $this->countSyllables($text);
        
        // Flesch-Kincaid Grade Level formula
        $grade = 0.39 * ($words / $sentences) + 11.8 * ($syllables / $words) - 15.59;
        
        if ($grade < 6) return '5th (Very Easy)';
        if ($grade < 8) return '7th (Easy)';
        if ($grade < 10) return '9th (Average)';
        if ($grade < 12) return '11th (Fairly Difficult)';
        if ($grade < 15) return 'College (Difficult)';
        return 'Graduate (Very Difficult)';
    }

    private function countSyllables(string $text): int {
        // Highly simplified syllable counting for performance
        // Only counts vowels as rough proxy
        $text = strtolower(preg_replace('/[^a-z]/', '', $text));
        $count = preg_match_all('/[aeiouy]+/', $text, $matches);
        $count -= preg_match_all('/e\b/', $text, $matches); // silent e
        return max(1, $count);
    }

    public function identifyEntities(string $content): array {
        // A placeholder for NLP-based entity extraction.
        // In this localized/standalone setup without an external NLP API,
        // we fallback to capitalizing frequent proper noun-like terms.
        
        $text = strip_tags($content);
        if (empty($text)) return [];
        
        preg_match_all('/([A-Z][a-z]+(?:\s[A-Z][a-z]+)*)/', $text, $matches);
        $entities = array_count_values($matches[1]);
        arsort($entities);
        // exclude common first words
        $excludes = ['The', 'A', 'An', 'In', 'On', 'It', 'He', 'She', 'This', 'That'];
        $filtered = [];
        foreach ($entities as $k => $v) {
            if ($v > 1 && !in_array($k, $excludes) && mb_strlen($k) > 3) {
                $filtered[] = ['entity' => $k, 'mentions' => $v];
            }
            if (count($filtered) >= 10) break;
        }
        return $filtered;
    }
}

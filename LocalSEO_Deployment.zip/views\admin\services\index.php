<?php ob_start(); ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="h4 mb-0"><?= $pageTitle ?></h2>
    <a href="/admin/services/create" class="btn btn-primary"><i class="bi bi-plus-lg"></i> Add New Service</a>
</div>

<div class="card bg-white shadow-sm border-0 mb-4">
    <div class="card-body border-bottom d-flex gap-2 py-2 bg-light rounded-top">
        <div class="d-flex gap-3 text-muted small align-items-center">
            <span class="text-dark fw-bold">All (<?= $counts['all'] ?>)</span> | 
            <span class="text-success">Published (<?= $counts['published'] ?>)</span> | 
            <span class="text-warning">Drafts (<?= $counts['draft'] ?>)</span>
        </div>
    </div>

    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead>
                <tr>
                    <th style="width: 50px;">Icon</th>
                    <th>Title</th>
                    <th>Price Range</th>
                    <th>SEO Score</th>
                    <th>Order</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php if(empty($services)): ?>
                    <tr><td colspan="6" class="text-center py-5 text-muted">No services found.</td></tr>
                <?php else: ?>
                    <?php foreach($services as $s): ?>
                        <tr>
                            <td class="text-center text-primary fs-3">
                                <?php if($s['icon_class']): ?>
                                    <i class="<?= htmlspecialchars($s['icon_class']) ?>"></i>
                                <?php else: ?>
                                    <i class="bi bi-box"></i>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="fw-bold mb-1">
                                    <a href="/admin/services/edit/<?= $s['id'] ?>" class="text-dark text-decoration-none"><?= htmlspecialchars($s['title']) ?></a>
                                </div>
                                <div class="small">
                                    <a href="/admin/services/edit/<?= $s['id'] ?>" class="text-primary text-decoration-none me-2">Edit</a>
                                    <a href="/services/<?= $s['slug'] ?>" target="_blank" class="text-muted text-decoration-none">View</a>
                                </div>
                            </td>
                            <td><?= htmlspecialchars($s['price_range'] ?? '--') ?></td>
                            <td>
                                <?php 
                                $score = $s['seo_score'];
                                $col = $score >= 80 ? 'success' : ($score >= 50 ? 'warning' : 'danger');
                                ?>
                                <span class="badge bg-<?= $col ?> bg-opacity-10 text-<?= $col ?> border border-<?= $col ?>"><?= $score ?>/100</span>
                            </td>
                            <td><?= $s['order_index'] ?></td>
                            <td>
                                <?php if($s['status'] === 'published'): ?>
                                    <span class="badge bg-success">Published</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">Draft</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php 
$content = ob_get_clean();
require dirname(__DIR__) . '/_layout.php';
?>

<?php
namespace Core;

class Security {
    public function getClientIP(): string {
        return Helpers::getClientIP();
    }

    public function isIPBlocked(string $ip): bool {
        try {
            $db = Database::getInstance();
            $t = $db->t('blocked_ips');
            $row = $db->fetch("SELECT * FROM {$t} WHERE ip_address = ? AND (is_permanent = 1 OR blocked_until > NOW()) LIMIT 1", [$ip]);
            return $row !== null;
        } catch (\Exception $e) { return false; }
    }

    public function checkRequest(): void {
        $uri = $_SERVER['REQUEST_URI'] ?? '';
        $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
        $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

        // SQL injection patterns
        $sqlPatterns = ['/union\s+select/i','/\bor\b\s+1\s*=\s*1/i','/;\s*drop\s+table/i','/;\s*delete\s+from/i','/load_file\s*\(/i','/into\s+outfile/i'];
        foreach ($sqlPatterns as $p) {
            if (preg_match($p, $uri) || preg_match($p, urldecode($uri))) {
                $this->logSecurity('sql_injection_attempt', null, null, $this->getClientIP(), 'high');
                $this->blockIP($this->getClientIP(), 'SQL injection attempt', 3600);
                http_response_code(403);
                exit('Forbidden');
            }
        }

        // XSS patterns
        $xssPatterns = ['/<script\b/i','/javascript\s*:/i','/on(error|load|click|mouseover)\s*=/i','/eval\s*\(/i'];
        foreach ($xssPatterns as $p) {
            if (preg_match($p, urldecode($uri))) {
                $this->logSecurity('xss_attempt', null, null, $this->getClientIP(), 'high');
                http_response_code(403);
                exit('Forbidden');
            }
        }

        // Directory traversal
        if (preg_match('/\.\.\/|\.\.\\\\/', $uri)) {
            $this->logSecurity('suspicious_activity', null, null, $this->getClientIP(), 'medium');
            http_response_code(403);
            exit('Forbidden');
        }
    }

    public function blockIP(string $ip, string $reason = '', int $duration = 0): void {
        try {
            $db = Database::getInstance();
            $t = $db->t('blocked_ips');
            $existing = $db->fetch("SELECT id, attempts FROM {$t} WHERE ip_address = ?", [$ip]);
            if ($existing) {
                $db->update($t, [
                    'reason' => $reason,
                    'attempts' => $existing['attempts'] + 1,
                    'blocked_until' => $duration > 0 ? date('Y-m-d H:i:s', time() + $duration) : null,
                    'is_permanent' => $duration === 0 ? 1 : 0,
                ], 'id = ?', [$existing['id']]);
            } else {
                $db->insert($t, [
                    'ip_address' => $ip,
                    'reason' => $reason,
                    'attempts' => 1,
                    'blocked_until' => $duration > 0 ? date('Y-m-d H:i:s', time() + $duration) : null,
                    'is_permanent' => $duration === 0 ? 1 : 0,
                ]);
            }
        } catch (\Exception $e) {}
    }

    public function logSecurity(string $eventType, ?int $userId = null, ?string $username = null, ?string $ip = null, string $severity = 'medium', ?string $additional = null): void {
        try {
            $db = Database::getInstance();
            $db->insert($db->t('security_log'), [
                'event_type' => $eventType,
                'user_id' => $userId,
                'username' => $username,
                'ip_address' => $ip ?? $this->getClientIP(),
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
                'request_uri' => $_SERVER['REQUEST_URI'] ?? '',
                'request_method' => $_SERVER['REQUEST_METHOD'] ?? '',
                'additional_data' => $additional,
                'severity' => $severity,
            ]);
        } catch (\Exception $e) {}
    }

    public function logActivity(string $action, ?int $userId = null, ?string $entityType = null, ?int $entityId = null, ?string $description = null): void {
        try {
            $db = Database::getInstance();
            $db->insert($db->t('activity_log'), [
                'user_id' => $userId,
                'action' => $action,
                'entity_type' => $entityType,
                'entity_id' => $entityId,
                'description' => $description,
                'ip_address' => $this->getClientIP(),
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
            ]);
        } catch (\Exception $e) {}
    }

    public function sanitizeInput(string $input): string {
        $input = trim($input);
        $input = stripslashes($input);
        $input = htmlspecialchars($input, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        return $input;
    }

    public function sanitizeHTML(string $html): string {
        $allowed = '<p><br><strong><b><em><i><u><a><ul><ol><li><h1><h2><h3><h4><h5><h6><blockquote><pre><code><img><table><thead><tbody><tr><th><td><div><span><hr><figure><figcaption><iframe>';
        return strip_tags($html, $allowed);
    }

    public function generateSecurityHeaders(): void {
        header('X-Content-Type-Options: nosniff');
        header('X-Frame-Options: SAMEORIGIN');
        header('X-XSS-Protection: 1; mode=block');
        header('Referrer-Policy: strict-origin-when-cross-origin');
    }
}

<?php ob_start(); ?>

<?php 
// Header background image logic
$headerBg = 'background-color: var(--primary-color);';
if ($service['featured_image_id']) {
    $db = \Core\Database::getInstance();
    $media = $db->fetch("SELECT file_path FROM {$db->t('media')} WHERE id = ?", [$service['featured_image_id']]);
    if ($media) {
        $headerBg = "background-image: linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.8)), url('/" . ltrim($media['file_path'], '/') . "'); background-size: cover; background-position: center;";
    }
}
?>

<div class="service-hero py-6 text-white position-relative" style="<?= $headerBg ?>">
    <div class="container py-5 position-relative z-1">
        <div class="row">
            <div class="col-lg-8">
                <nav aria-label="breadcrumb">
                  <ol class="breadcrumb mb-3">
                    <li class="breadcrumb-item"><a href="/" class="text-white-50 text-decoration-none">Home</a></li>
                    <li class="breadcrumb-item"><a href="/services" class="text-white-50 text-decoration-none">Services</a></li>
                    <li class="breadcrumb-item active text-white" aria-current="page"><?= \Core\Helpers::escape($service['title']) ?></li>
                  </ol>
                </nav>
                <div class="d-flex align-items-center mb-3">
                    <i class="<?= \Core\Helpers::escape($service['icon_class'] ?: 'bi bi-star') ?> fs-2 me-3 text-warning"></i>
                    <h1 class="display-4 fw-bolder mb-0"><?= \Core\Helpers::escape($service['title']) ?></h1>
                </div>
                <p class="lead fs-4 opacity-75 max-w-700"><?= \Core\Helpers::escape($service['short_description']) ?></p>
                <div class="mt-4 pt-2">
                    <a href="/contact?service=<?= urlencode($service['title']) ?>" class="btn btn-warning btn-lg rounded-pill px-5 py-3 fw-bold shadow-sm text-dark me-3">
                        Get Started <i class="bi bi-arrow-right ms-2"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container py-5 my-4">
    <div class="row">
        <!-- Main Content -->
        <div class="col-lg-8 mb-5 mb-lg-0">
            <article class="content-formatted fs-5 bg-white p-4 p-md-5 rounded-4 shadow-sm border">
                <?= $service['content'] ?>
            </article>
        </div>
        
        <!-- Sidebar -->
        <div class="col-lg-4 ps-lg-5">
            <div class="sticky-sidebar top-100">
                <div class="card border-0 shadow-sm rounded-4 mb-4 bg-light">
                    <div class="card-body p-4 text-center">
                        <h4 class="fw-bold mb-3">Need this service?</h4>
                        <p class="text-muted mb-4">Our local SEO experts are ready to implement this for your business.</p>
                        <a href="/contact" class="btn btn-primary w-100 rounded-pill py-3 fw-bold mb-3">Request a Quote</a>
                        <a href="tel:<?= \Core\Helpers::escape(\Core\Helpers::setting('seo_business_phone', '+923000000000')) ?>" class="btn btn-outline-dark w-100 rounded-pill py-3 fw-bold">
                            <i class="bi bi-telephone mb-0 me-2"></i> Call Now
                        </a>
                    </div>
                </div>

                <div class="card border-0 shadow-sm rounded-4">
                    <div class="card-body p-4">
                        <h5 class="fw-bold mb-3 border-bottom pb-2">Other Services</h5>
                        <ul class="list-unstyled mb-0 service-sidebar-list">
                            <?php 
                            $db = \Core\Database::getInstance();
                            $otherServices = $db->fetchAll("SELECT id, title, slug FROM {$db->t('services')} WHERE status='published' AND id != ? ORDER BY order_index ASC LIMIT 5", [$service['id']]);
                            foreach ($otherServices as $s): ?>
                                <li class="mb-3"><a href="/services/<?= \Core\Helpers::escape($s['slug']) ?>" class="text-decoration-none text-dark fw-medium d-flex align-items-center"><i class="bi bi-chevron-right text-primary me-2 ms-0 small"></i> <?= \Core\Helpers::escape($s['title']) ?></a></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .py-6 { padding-top: 6rem!important; padding-bottom: 6rem!important; }
    .max-w-700 { max-width: 700px; }
    .sticky-sidebar { position: sticky; top: 100px; }
    .content-formatted h2 { margin-top: 2rem; margin-bottom: 1rem; font-weight: 700; color: #0f172a; }
    .content-formatted h3 { margin-top: 1.5rem; margin-bottom: 1rem; font-weight: 600; }
    .content-formatted p { line-height: 1.8; color: #475569; margin-bottom: 1.5rem; }
    .content-formatted ul, .content-formatted ol { margin-bottom: 1.5rem; color: #475569; line-height: 1.8; padding-left: 1.5rem; }
    .content-formatted li { margin-bottom: 0.5rem; }
    .service-sidebar-list a:hover { color: var(--primary-color)!important; padding-left: 5px; transition: all 0.2s; }
</style>

<?php
$content = ob_get_clean();
require VIEW_PATH . '/frontend/_layout.php';
?>

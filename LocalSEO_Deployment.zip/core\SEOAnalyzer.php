<?php
namespace Core;

class SEOAnalyzer {
    public function analyze(string $content, string $title, string $focusKeyword, array $secondaryKeywords = []): array {
        $checks = [];
        $score = 0;
        $maxScore = 0;

        $contentRaw = strip_tags($content);
        $wordCount = str_word_count($contentRaw);
        $focusKeywordLower = strtolower($focusKeyword);
        $titleLower = strtolower($title);
        $contentLower = strtolower($contentRaw);

        // Word count
        $maxScore += 15;
        if ($wordCount > 1000) { $checks['word_count'] = ['status' => 'pass', 'msg' => "Content is {$wordCount} words long (excellent)."]; $score += 15; }
        elseif ($wordCount > 500) { $checks['word_count'] = ['status' => 'warn', 'msg' => "Content is {$wordCount} words. Aim for 1000+ words."]; $score += 10; }
        else { $checks['word_count'] = ['status' => 'fail', 'msg' => "Content is too short ({$wordCount} words). Minimum recommended is 500."]; $score += 0; }

        if ($focusKeywordLower) {
            // Keyword in Title
            $maxScore += 15;
            if (strpos($titleLower, $focusKeywordLower) !== false) {
                $checks['kw_in_title'] = ['status' => 'pass', 'msg' => 'Focus keyword found in SEO Title.'];
                $score += 15;
                // Keyword at beginning of title
                $maxScore += 10;
                if (strpos($titleLower, $focusKeywordLower) === 0) {
                    $checks['kw_at_beginning_title'] = ['status' => 'pass', 'msg' => 'Focus keyword is at the beginning of the title.'];
                    $score += 10;
                } else {
                    $checks['kw_at_beginning_title'] = ['status' => 'warn', 'msg' => 'Consider moving the focus keyword to the beginning of the title.'];
                    $score += 5;
                }
            } else {
                $checks['kw_in_title'] = ['status' => 'fail', 'msg' => 'Focus keyword not found in SEO Title.'];
                $score += 0;
                $maxScore += 10; // Penalty trick if not beginning
            }

            // Keyword in content
            $maxScore += 20;
            $kwCount = substr_count($contentLower, $focusKeywordLower);
            if ($kwCount > 0) {
                $density = round(($kwCount * str_word_count($focusKeywordLower) / max(1, $wordCount)) * 100, 2);
                if ($density >= 0.5 && $density <= 2.5) {
                    $checks['kw_density'] = ['status' => 'pass', 'msg' => "Keyword density is {$density}% ({$kwCount} times), which is optimal."];
                    $score += 20;
                } elseif ($density > 2.5) {
                    $checks['kw_density'] = ['status' => 'warn', 'msg' => "Keyword density is {$density}% ({$kwCount} times) - this might be considered keyword stuffing."];
                    $score += 10;
                } else {
                    $checks['kw_density'] = ['status' => 'warn', 'msg' => "Keyword density is {$density}% ({$kwCount} times). Could be used more."];
                    $score += 12;
                }
            } else {
                $checks['kw_density'] = ['status' => 'fail', 'msg' => 'Focus keyword not found in content.'];
            }

            // Keyword in first 10%
            $maxScore += 10;
            $first100Words = implode(' ', array_slice(explode(' ', $contentLower), 0, (int)max(100, $wordCount * 0.1)));
            if (strpos($first100Words, $focusKeywordLower) !== false) {
                $checks['kw_first_10percent'] = ['status' => 'pass', 'msg' => 'Focus keyword found in the first 10% of content.'];
                $score += 10;
            } else {
                $checks['kw_first_10percent'] = ['status' => 'warn', 'msg' => 'Focus keyword not found in the introductory content.'];
                $score += 3;
            }

            // Keyword in H2/H3
            $maxScore += 10;
            preg_match_all('/<h[2-3][^>]*>(.*?)<\/h[2-3]>/is', $content, $headings);
            $foundInHeading = false;
            foreach ($headings[1] as $heading) {
                if (strpos(strtolower(strip_tags($heading)), $focusKeywordLower) !== false) {
                    $foundInHeading = true; break;
                }
            }
            if ($foundInHeading) {
                $checks['kw_in_subheadings'] = ['status' => 'pass', 'msg' => 'Focus keyword found in H2 or H3 subheadings.'];
                $score += 10;
            } else {
                $checks['kw_in_subheadings'] = ['status' => 'warn', 'msg' => 'Focus keyword not found in any H2 or H3 subheading.'];
                $score += 5;
            }
        }

        // Title length
        $titleLen = mb_strlen($title);
        $maxScore += 10;
        if ($titleLen >= 40 && $titleLen <= 60) {
            $checks['title_length'] = ['status' => 'pass', 'msg' => "Title length is {$titleLen} chars (optimal 40-60)."];
            $score += 10;
        } else {
            $checks['title_length'] = ['status' => 'warn', 'msg' => "Title length is {$titleLen} chars. Optimal is between 40 and 60."];
            $score += 4;
        }

        // Internal Output
        $internalLinks = substr_count(strtolower($content), 'href="') 
                        - substr_count(strtolower($content), 'href="http')
                        + substr_count(strtolower($content), 'href="' . rtrim(APP_URL, '/'));
                        
        $maxScore += 10;
        if ($internalLinks > 0) {
            $checks['internal_links'] = ['status' => 'pass', 'msg' => "We found {$internalLinks} internal links."];
            $score += 10;
        } else {
            $checks['internal_links'] = ['status' => 'fail', 'msg' => 'No internal links found in the content.'];
            $score += 0;
        }

        // Outbound links
        $outboundLinks = substr_count(strtolower($content), 'href="http')
                       - substr_count(strtolower($content), 'href="' . rtrim(APP_URL, '/'));
        $maxScore += 10;
        if ($outboundLinks > 0) {
            $checks['outbound_links'] = ['status' => 'pass', 'msg' => "We found {$outboundLinks} outbound/external links."];
            $score += 10;
        } else {
            $checks['outbound_links'] = ['status' => 'warn', 'msg' => 'No outbound links found. Include natural citations.'];
            $score += 5;
        }

        $finalScore = $maxScore > 0 ? (int) round(($score / $maxScore) * 100) : 0;
        return [
            'score' => $finalScore,
            'checks' => $checks
        ];
    }

    public function getReadability(string $content): array {
        $text = strip_tags($content);
        $wordCount = max(1, str_word_count($text));
        
        // Simple metric heuristics - rough estimate for performance
        $sentenceCount = max(1, preg_match_all('/[.!?]+/', $text, $matches));
        $avgWordsPerSentence = $wordCount / $sentenceCount;
        
        $checks = [];
        $score = 100;

        if ($avgWordsPerSentence > 20) {
            $checks['sentence_length'] = ['status' => 'warn', 'msg' => 'Sentences are too long on average (' . round($avgWordsPerSentence, 1) . ' words). Keep it under 20.'];
            $score -= 20;
        } else {
            $checks['sentence_length'] = ['status' => 'pass', 'msg' => 'Great sentence length (' . round($avgWordsPerSentence, 1) . ' words average).'];
        }

        // Paragraph length (rough: count blocks of text separated by newlines)
        $paragraphs = array_filter(preg_split('/\n\s*\n/', $text));
        $longParas = 0;
        foreach ($paragraphs as $p) {
            if (str_word_count($p) > 150) $longParas++;
        }
        if ($longParas > 0) {
            $checks['paragraph_length'] = ['status' => 'warn', 'msg' => "{$longParas} paragraphs contain more than 150 words. Break them up."];
            $score -= 15;
        } else {
            $checks['paragraph_length'] = ['status' => 'pass', 'msg' => 'Paragraph lengths are well-paced.'];
        }

        return ['score' => max(0, $score), 'checks' => $checks];
    }
}

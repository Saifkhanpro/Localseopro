<?php
namespace Controllers\Admin;
use Core\Controller;
use Core\Helpers;
use Models\Post;
use Models\Category;
use Models\Tag;

class PostController extends Controller {
    public function index() {
        $this->requireRole(['super_admin', 'admin', 'editor', 'author', 'contributor']);
        
        $postModel = new Post();
        $db = \Core\Database::getInstance();
        $page = (int)$this->input('p', 1);
        $perPage = 20;
        
        $user = $this->auth->user();
        $where = "post_type = 'post'";
        $params = [];

        // Authors/Contributors only see their own posts unless they have higher perms
        if (in_array($user['role'], ['author', 'contributor'])) {
            $where .= " AND author_id = ?";
            $params[] = $user['id'];
        }

        $s = $this->input('s');
        if ($s) {
            $where .= " AND title LIKE ?";
            $params[] = "%{$s}%";
        }

        $status = $this->input('status');
        if ($status && in_array($status, ['published', 'draft', 'trash', 'pending'])) {
            $where .= " AND status = ?";
            $params[] = $status;
        } elseif (!$status) {
            $where .= " AND status != 'trash'";
        }

        $paginated = $postModel->paginate($page, $perPage, $where, $params, "updated_at DESC");

        // Attach authors
        foreach ($paginated['items'] as &$item) {
            $item['author'] = $db->fetchColumn("SELECT display_name FROM {$db->t('users')} WHERE id = ?", [$item['author_id']]);
        }

        $this->adminView('posts/index', [
            'pageTitle' => 'All Posts',
            'posts' => $paginated['items'],
            'pagination' => $paginated,
            'counts' => [
                'all' => $postModel->count("post_type='post' AND status != 'trash'"),
                'published' => $postModel->count("post_type='post' AND status='published'"),
                'draft' => $postModel->count("post_type='post' AND status='draft'"),
                'trash' => $postModel->count("post_type='post' AND status='trash'")
            ]
        ]);
    }

    public function create() {
        $this->requireRole(['super_admin', 'admin', 'editor', 'author', 'contributor']);
        $catModel = new Category();
        
        $this->adminView('posts/form', [
            'pageTitle' => 'Add New Post',
            'post' => null,
            'categories' => $catModel->getTree()
        ]);
    }

    public function edit(int $id) {
        $this->requireRole(['super_admin', 'admin', 'editor', 'author', 'contributor']);
        
        $postModel = new Post();
        $post = $postModel->find($id);

        if (!$post || $post['post_type'] !== 'post') {
            Helpers::flash('error', 'Post not found.');
            $this->redirect('/admin/posts');
            return;
        }

        $user = $this->auth->user();
        if (in_array($user['role'], ['author', 'contributor']) && $post['author_id'] != $user['id']) {
            Helpers::flash('error', 'You do not have permission to edit this post.');
            $this->redirect('/admin/posts');
            return;
        }

        $catModel = new Category();
        $postCats = array_column($postModel->getCategories($id), 'id');
        
        $tags = array_column($postModel->getTags($id), 'name');
        $tagsString = implode(', ', $tags);

        // Get featured image URL if exists
        $featuredImageUrl = '';
        if ($post['featured_image_id']) {
            $db = \Core\Database::getInstance();
            $media = $db->fetch("SELECT file_path FROM {$db->t('media')} WHERE id = ?", [$post['featured_image_id']]);
            if ($media) $featuredImageUrl = '/' . $media['file_path'];
        }

        $this->adminView('posts/form', [
            'pageTitle' => 'Edit Post',
            'post' => $post,
            'postCategories' => $postCats,
            'tagsString' => $tagsString,
            'categories' => $catModel->getTree(),
            'featuredImageUrl' => $featuredImageUrl
        ]);
    }

    public function save() {
        $this->requireRole(['super_admin', 'admin', 'editor', 'author', 'contributor']);
        $this->verifyCsrf();

        $id = (int)$this->input('id', 0);
        $postModel = new Post();
        $user = $this->auth->user();

        // Security check for editing
        if ($id > 0) {
            $existing = $postModel->find($id);
            if (!$existing) {
                Helpers::flash('error', 'Post not found.');
                $this->redirect('/admin/posts');
                return;
            }
            if (in_array($user['role'], ['author', 'contributor']) && $existing['author_id'] != $user['id']) {
                $this->redirect('/admin/posts');
                return;
            }
        }

        $title = $this->input('title');
        
        // Generate slug ensuring uniqueness
        $slugInput = $this->input('slug') ?: $title;
        $slug = Helpers::generateUniqueSlug($slugInput, 'posts', $id);

        $status = $this->input('status', 'draft');
        if ($user['role'] === 'contributor' && $status === 'published') {
            $status = 'pending'; // Contributors cannot publish directly
        }

        $now = date('Y-m-d H:i:s');
        $publishedAt = $this->input('published_at');
        if ($status === 'published' && !$publishedAt) {
            $publishedAt = $now;
        }

        // Run SEO analysis if content changed
        $content = $_POST['content'] ?? '';
        $seoTitle = $this->input('seo_title');
        $focusKw = $this->input('focus_keyword', '');
        
        $seoAnalyzer = new \Core\SEOAnalyzer();
        $seoAnalysis = $seoAnalyzer->analyze($content, $seoTitle ?: $title, $focusKw);
        $readAnalysis = $seoAnalyzer->getReadability($content);

        $data = [
            'author_id' => $id > 0 ? $existing['author_id'] : $user['id'],
            'title' => $title,
            'slug' => $slug,
            'content' => $content,
            'excerpt' => $this->input('excerpt', ''),
            'status' => $status,
            'post_type' => 'post',
            'visibility' => $this->input('visibility', 'public'),
            'password' => $this->input('password', ''),
            'featured_image_id' => $this->input('featured_image_id') ?: null,
            'comment_status' => $this->input('comment_status', 'open'),
            'ping_status' => $this->input('ping_status', 'open'),
            'focus_keyword' => $focusKw,
            'secondary_keywords' => $this->input('secondary_keywords', ''),
            'seo_title' => $seoTitle,
            'meta_description' => $this->input('meta_description', ''),
            'robots_index' => $this->input('robots_index', 'default'),
            'robots_follow' => $this->input('robots_follow', 'default'),
            'robots_advanced' => implode(',', (array)$this->input('robots_advanced', [])),
            'canonical_url' => $this->input('canonical_url', ''),
            'primary_category_id' => $this->input('primary_category_id') ?: null,
            'readability_score' => $readAnalysis['score'],
            'seo_score' => $seoAnalysis['score'],
            'schema_type' => $this->input('schema_type', 'Article')
        ];

        if ($status === 'published') $data['published_at'] = $publishedAt;

        if ($id > 0) {
            $postModel->update($id, $data);
            $postId = $id;
            $this->security->logActivity('update_post', $user['id'], 'post', $id, "Updated post: {$title}");
            Helpers::flash('success', 'Post updated successfully.');
        } else {
            $postId = $postModel->create($data);
            $this->security->logActivity('create_post', $user['id'], 'post', $postId, "Created post: {$title}");
            Helpers::flash('success', 'Post created successfully.');
        }

        // Sync Categories
        $categories = (array)($this->input('categories') ?? []);
        $postModel->syncCategories($postId, $categories);

        // Sync Tags
        $tagsInput = $this->input('tags', '');
        $tagModel = new Tag();
        $tagNames = array_filter(array_map('trim', explode(',', $tagsInput)));
        $tagIds = $tagModel->getOrCreate($tagNames);
        $postModel->syncTags($postId, $tagIds);

        // Clear Caches
        $cm = new \Core\CacheMonitor();
        $cm->clearType('pages');
        $cm->clearType('objects');

        $this->redirect('/admin/posts/edit/' . $postId);
    }

    public function action() {
        $this->requireRole(['super_admin', 'admin', 'editor']);
        $this->verifyCsrf();

        $action = $this->input('action');
        $ids = (array)$this->input('ids', []);

        if (empty($ids) || empty($action)) {
            $this->redirect('/admin/posts');
            return;
        }

        $postModel = new Post();
        $db = \Core\Database::getInstance();
        $count = 0;

        foreach ($ids as $id) {
            $id = (int)$id;
            if ($action === 'trash') {
                $postModel->update($id, ['status' => 'trash']);
                $count++;
            } elseif ($action === 'restore') {
                $postModel->update($id, ['status' => 'draft']);
                $count++;
            } elseif ($action === 'delete') {
                $postModel->delete($id);
                // Cleanup pivots
                $db->delete($db->t('post_categories'), 'post_id=?', [$id]);
                $db->delete($db->t('post_tags'), 'post_id=?', [$id]);
                $count++;
            }
        }

        if ($count > 0) {
            $cm = new \Core\CacheMonitor();
            $cm->clearType('pages');
            Helpers::flash('success', "Bulk action '{$action}' applied to {$count} posts.");
        }

        $this->redirect('/admin/posts');
    }
}

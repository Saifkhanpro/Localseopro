<?php
namespace Controllers\Admin;
use Core\Controller;
class CacheController extends Controller {
    public function __call($name, $arguments) {
        $this->requireAuth();
        echo "<h1>Under Construction</h1><p>Cache module ($name) is being built.</p>";
    }
}

<?php
namespace Core;

class SchemaGenerator {
    public function generateOrganization(): array {
        $settings = $GLOBALS['settings'] ?? [];
        return [
            '@context' => 'https://schema.org',
            '@type' => 'Organization',
            'name' => $settings['seo_business_name'] ?? 'LocalSEO.pk',
            'url' => rtrim($settings['site_url'] ?? APP_URL, '/'),
            'logo' => $settings['logo_url'] ?? '',
            'contactPoint' => [
                '@type' => 'ContactPoint',
                'telephone' => $settings['seo_business_phone'] ?? '',
                'contactType' => 'customer service'
            ]
        ];
    }

    public function generateLocalBusiness(): array {
        $settings = $GLOBALS['settings'] ?? [];
        $schema = [
            '@context' => 'https://schema.org',
            '@type' => $settings['seo_business_type'] ?? 'LocalBusiness',
            'name' => $settings['seo_business_name'] ?? 'LocalSEO.pk',
            'image' => $settings['logo_url'] ?? '',
            '@id' => rtrim($settings['site_url'] ?? APP_URL, '/') . '#organization',
            'url' => rtrim($settings['site_url'] ?? APP_URL, '/'),
            'telephone' => $settings['seo_business_phone'] ?? '',
            'address' => [
                '@type' => 'PostalAddress',
                'streetAddress' => $settings['seo_business_street'] ?? '',
                'addressLocality' => $settings['seo_business_city'] ?? '',
                'addressRegion' => $settings['seo_business_state'] ?? '',
                'postalCode' => $settings['seo_business_postal'] ?? '',
                'addressCountry' => $settings['seo_business_country'] ?? 'PK'
            ],
            'geo' => [
                '@type' => 'GeoCoordinates',
                'latitude' => $settings['seo_business_latitude'] ?? '',
                'longitude' => $settings['seo_business_longitude'] ?? ''
            ],
            'openingHoursSpecification' => [
                '@type' => 'OpeningHoursSpecification',
                'dayOfWeek' => ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'],
                'opens' => '09:00',
                'closes' => '18:00'
            ],
            'priceRange' => $settings['seo_business_price_range'] ?? '$$'
        ];
        return $schema;
    }

    public function generateArticle(array $post): array {
        return [
            '@context' => 'https://schema.org',
            '@type' => 'BlogPosting',
            'mainEntityOfPage' => [
                '@type' => 'WebPage',
                '@id' => rtrim(APP_URL, '/') . '/blog/' . $post['slug']
            ],
            'headline' => $post['title'],
            'description' => $post['meta_description'] ?? $post['excerpt'] ?? '',
            'image' => $post['featured_image_url'] ?? '',
            'author' => [
                '@type' => 'Person',
                'name' => $post['author_name'] ?? 'Admin',
                'url' => rtrim(APP_URL, '/') . '/author/' . ($post['author_name'] ?? 'admin')
            ],
            'publisher' => $this->generateOrganization(),
            'datePublished' => date('c', strtotime($post['published_at'] ?? $post['created_at'])),
            'dateModified' => date('c', strtotime($post['updated_at']))
        ];
    }

    public function generateService(array $service): array {
        return [
            '@context' => 'https://schema.org',
            '@type' => 'Service',
            'name' => $service['title'],
            'description' => $service['meta_description'] ?? $service['short_description'] ?? '',
            'provider' => $this->generateLocalBusiness(),
            'serviceType' => 'Local SEO'
        ];
    }
    
    public function generateBreadcrumbs(array $crumbs): array {
        $list = [];
        $pos = 1;
        foreach ($crumbs as $name => $url) {
            $list[] = [
                '@type' => 'ListItem',
                'position' => $pos++,
                'name' => strip_tags($name),
                'item' => rtrim(APP_URL, '/') . '/' . ltrim($url, '/')
            ];
        }
        return [
            '@context' => 'https://schema.org',
            '@type' => 'BreadcrumbList',
            'itemListElement' => $list
        ];
    }
}

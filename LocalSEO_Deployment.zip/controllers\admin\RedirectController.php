<?php
namespace Controllers\Admin;
use Core\Controller;
class RedirectController extends Controller {
    public function __call($name, $arguments) {
        $this->requireAuth();
        echo "<h1>Under Construction</h1><p>Redirects module ($name) is being built.</p>";
    }
}

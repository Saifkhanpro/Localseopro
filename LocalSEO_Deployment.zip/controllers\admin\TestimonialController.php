<?php
namespace Controllers\Admin;

use Core\Controller;
use Core\Helpers;
use Models\Testimonial;

class TestimonialController extends Controller {
    public function index() {
        $this->requireRole(['super_admin', 'admin', 'editor']);
        
        $testModel = new Testimonial();
        $page = (int)$this->input('p', 1);
        $perPage = 20;
        
        $where = "1=1";
        $params = [];

        $s = $this->input('s');
        if ($s) {
            $where .= " AND (client_name LIKE ? OR company_name LIKE ? OR content LIKE ?)";
            $params[] = "%{$s}%";
            $params[] = "%{$s}%";
            $params[] = "%{$s}%";
        }

        $status = $this->input('status');
        if ($status && in_array($status, ['approved', 'pending', 'rejected'])) {
            $where .= " AND status = ?";
            $params[] = $status;
        }

        $paginated = $testModel->paginate($page, $perPage, $where, $params, "created_at DESC");

        $this->adminView('testimonials/index', [
            'pageTitle' => 'Testimonials',
            'testimonials' => $paginated['items'],
            'pagination' => $paginated
        ]);
    }

    public function save() {
        $this->requireRole(['super_admin', 'admin', 'editor']);
        $this->verifyCsrf();

        $id = (int)$this->input('id', 0);
        $testModel = new Testimonial();

        $clientName = trim($this->input('client_name'));
        if (empty($clientName)) {
            Helpers::flash('error', 'Client name is required.');
            $this->redirect('/admin/testimonials');
            return;
        }

        $data = [
            'client_name' => $clientName,
            'company_name' => $this->input('company_name', ''),
            'position' => $this->input('position', ''),
            'content' => $this->input('content', ''),
            'rating' => (int)$this->input('rating', 5),
            'status' => $this->input('status', 'approved'),
            'avatar_url' => $this->input('avatar_url', ''),
            'video_url' => $this->input('video_url', '')
        ];

        if ($id > 0) {
            $testModel->update($id, $data);
            Helpers::flash('success', 'Testimonial updated successfully.');
        } else {
            $testModel->create($data);
            Helpers::flash('success', 'Testimonial created successfully.');
        }

        $cm = new \Core\CacheMonitor();
        $cm->clearType('pages');
        $this->redirect('/admin/testimonials');
    }

    public function delete(int $id) {
        $this->requireRole(['super_admin', 'admin', 'editor']);
        $testModel = new Testimonial();
        
        $test = $testModel->find($id);
        if ($test) {
            $testModel->delete($id);
            Helpers::flash('success', 'Testimonial deleted successfully.');
            
            $cm = new \Core\CacheMonitor();
            $cm->clearType('pages');
        }
        $this->redirect('/admin/testimonials');
    }
}

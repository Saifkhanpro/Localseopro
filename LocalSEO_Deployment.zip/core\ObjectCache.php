<?php
namespace Core;

class ObjectCache extends Cache {
    public function __construct() { parent::__construct('objects'); }
    public function remember(string $key, int $ttl, callable $callback) {
        $cached = $this->get($key);
        if ($cached !== null) return $cached;
        $value = $callback();
        $this->set($key, $value, $ttl);
        return $value;
    }
    public function tags(string $tag): self {
        $this->cachePath = CACHE_PATH . '/objects/' . $tag;
        if (!is_dir($this->cachePath)) @mkdir($this->cachePath, 0755, true);
        return $this;
    }
}

<?php
namespace Controllers\Frontend;
use Core\Controller;
use Models\Page;

class PageController extends Controller {
    public function show(string $slug) {
        $pageModel = new Page();
        $page = $pageModel->findBySlug($slug);

        if (!$page || $page['status'] !== 'published') {
            http_response_code(404);
            $this->frontendView('404', ['pageTitle' => 'Page Not Found']);
            return;
        }

        $template = !empty($page['template']) ? $page['template'] : 'default';
        $viewName = 'pages/' . $template;

        // Fallback to default if custom template doesn't exist
        if (!file_exists(VIEW_PATH . '/frontend/' . $viewName . '.php')) {
            $viewName = 'pages/default';
        }

        $data = [
            'page' => $page,
            'pageTitle' => $page['seo_title'] ?: $page['title'],
            'metaDescription' => $page['meta_description'],
            'canonicalUrl' => $page['canonical_url'] ?: APP_URL . '/' . $page['slug'],
            'schema' => json_decode($page['schema_data'] ?? '[]', true),
            'robots' => []
        ];

        if ($page['robots_index'] === 'noindex') $data['robots'][] = 'noindex';
        if ($page['robots_follow'] === 'nofollow') $data['robots'][] = 'nofollow';
        if ($page['robots_advanced']) $data['robots'][] = $page['robots_advanced'];

        $this->frontendView($viewName, $data);
    }
}

<?php
namespace Models;
use Core\Model;

class Team extends Model {
    protected $table = 'team';
    protected $fillable = ['name', 'designation', 'bio', 'avatar_id', 'facebook_url', 'twitter_url', 'linkedin_url', 'order_index', 'status'];
}

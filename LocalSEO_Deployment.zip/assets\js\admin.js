/** LocalSEO.pk Admin JS */
document.addEventListener('DOMContentLoaded', function() {
    console.log('Admin Panel initialized.');
    
    // Auto-dismiss alerts after 5 seconds
    setTimeout(function() {
        let alerts = document.querySelectorAll('.alert-dismissible');
        alerts.forEach(function(alert) {
            let bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        });
    }, 5000);
});

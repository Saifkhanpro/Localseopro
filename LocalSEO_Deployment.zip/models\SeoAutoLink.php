<?php
namespace Models;
use Core\Model;

class SeoAutoLink extends Model {
    protected $table = 'seo_auto_links';
    protected $fillable = [
        'keyword', 'target_url', 'priority', 'max_links_per_post', 'is_active',
        'exclude_posts', 'current_count'
    ];
}

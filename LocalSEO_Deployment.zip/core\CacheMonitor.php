<?php
namespace Core;

class CacheMonitor {
    public function getStats(): array {
        $pageCache = new Cache('pages');
        $objectCache = new Cache('objects');
        $queryCache = new Cache('queries');
        $assetCache = new Cache('assets');
        return [
            'page' => ['size' => $pageCache->getSize(), 'files' => $pageCache->getFileCount()],
            'object' => ['size' => $objectCache->getSize(), 'files' => $objectCache->getFileCount()],
            'query' => ['size' => $queryCache->getSize(), 'files' => $queryCache->getFileCount()],
            'asset' => ['size' => $assetCache->getSize(), 'files' => $assetCache->getFileCount()],
            'total_size' => $pageCache->getSize() + $objectCache->getSize() + $queryCache->getSize() + $assetCache->getSize(),
        ];
    }

    public function clearAll(): array {
        $counts = [];
        $dirs = ['pages','objects','queries','assets/css','assets/js','critical-css','sitemaps','meta'];
        foreach ($dirs as $d) {
            $c = new Cache($d);
            $counts[$d] = $c->clear();
        }
        return $counts;
    }

    public function clearType(string $type): int {
        $c = new Cache($type);
        return $c->clear();
    }
}

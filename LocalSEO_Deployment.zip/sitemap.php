<?php
/**
 * LocalSEO.pk — Dynamic Sitemap Handler
 * Version: 1.0.0
 */

define('LSEO_INIT', true);
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/core/Database.php';

$db = \Core\Database::getInstance();
$prefix = $db->getTablePrefix();

$type = $_GET['type'] ?? 'index';

function renderSitemapLinks($links) {
    header('Content-Type: application/xml; charset=utf-8');
    echo '<?xml version="1.0" encoding="UTF-8"?>';
    echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">';
    foreach ($links as $link) {
        echo '<url>';
        echo '<loc>' . htmlspecialchars($link['loc']) . '</loc>';
        echo '<lastmod>' . $link['lastmod'] . '</lastmod>';
        echo '<changefreq>' . ($link['changefreq'] ?? 'weekly') . '</changefreq>';
        echo '<priority>' . ($link['priority'] ?? '0.8') . '</priority>';
        echo '</url>';
    }
    echo '</urlset>';
}

if ($type === 'index') {
    header('Content-Type: application/xml; charset=utf-8');
    echo '<?xml version="1.0" encoding="UTF-8"?>';
    echo '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';
    $sitemaps = ['post-sitemap.xml', 'page-sitemap.xml', 'service-sitemap.xml', 'city-sitemap.xml', 'category-sitemap.xml', 'case-study-sitemap.xml'];
    foreach ($sitemaps as $sm) {
        echo '<sitemap><loc>' . APP_URL . '/' . $sm . '</loc><lastmod>' . date('c') . '</lastmod></sitemap>';
    }
    echo '</sitemapindex>';
} else {
    $links = [];
    $tableMap = [
        'post' => ['table' => 'posts', 'route' => '/blog/', 'priority' => '0.8'],
        'page' => ['table' => 'pages', 'route' => '/', 'priority' => '0.9'],
        'service' => ['table' => 'services', 'route' => '/services/', 'priority' => '0.9'],
        'city' => ['table' => 'city_pages', 'route' => '/local-seo/', 'priority' => '1.0'],
        'category' => ['table' => 'categories', 'route' => '/category/', 'priority' => '0.6'],
        'case-study' => ['table' => 'case_studies', 'route' => '/case-studies/', 'priority' => '0.8'],
    ];

    if (isset($tableMap[$type])) {
        $cfg = $tableMap[$type];
        
        $statusClause = "status = 'published'";
        if ($type === 'category') $statusClause = "1=1"; 

        $items = $db->fetchAll("SELECT slug, updated_at FROM {$prefix}{$cfg['table']} WHERE {$statusClause}");
        
        foreach ($items as $item) {
            $links[] = [
                'loc' => APP_URL . $cfg['route'] . $item['slug'],
                'lastmod' => date('c', strtotime($item['updated_at'] ?? 'now')),
                'priority' => $cfg['priority']
            ];
        }
    }

    renderSitemapLinks($links);
}

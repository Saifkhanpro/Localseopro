<?php
namespace Core;

class SiteHealth {
    public function getReport(): array {
        $report = [
            'score' => 100,
            'critical' => [],
            'recommended' => [],
            'good' => [],
            'info' => [
                'php_version' => PHP_VERSION,
                'mysql_version' => $this->getDbVersion(),
                'server' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown',
                'cms_version' => defined('APP_VERSION') ? APP_VERSION : '1.0.0',
            ]
        ];

        // 1. Check PHP Version
        $minPhp = defined('LSEO_MIN_PHP') ? LSEO_MIN_PHP : '8.0.0';
        if (version_compare(PHP_VERSION, $minPhp, '<')) {
            $report['critical'][] = "PHP version is too old. Requires {$minPhp}+.";
            $report['score'] -= 20;
        } else {
            $report['good'][] = 'PHP version is up to date.';
        }

        // 2. Extensions Check
        $requiredExts = ['pdo_mysql', 'gd', 'curl', 'zip', 'json', 'mbstring'];
        foreach ($requiredExts as $ext) {
            if (!extension_loaded($ext)) {
                $report['critical'][] = "Required PHP extension missing: {$ext}";
                $report['score'] -= 10;
            }
        }
        if (empty($report['critical'])) $report['good'][] = 'All required PHP extensions are loaded.';

        // 3. Writable Directories
        $dirs = ['uploads', 'cache', 'backups'];
        foreach ($dirs as $dir) {
            if (!is_writable(ROOT_PATH . '/' . $dir)) {
                $report['critical'][] = "Directory /{$dir} is not writable.";
                $report['score'] -= 5;
            }
        }
        if ($report['score'] >= 90) $report['good'][] = 'Important directories are writable.';

        // 4. HTTPS Check
        if (empty($_SERVER['HTTPS']) || $_SERVER['HTTPS'] === 'off') {
            $report['critical'][] = 'Your site is not using HTTPS. This is critical for security and SEO.';
            $report['score'] -= 15;
        } else {
            $report['good'][] = 'Site is securely using HTTPS.';
        }

        // 5. Caching
        if ((Helpers::setting('cache_enabled', '1')) !== '1') {
            $report['recommended'][] = 'Page caching is disabled. Enabling it will drastically improve performance.';
            $report['score'] -= 5;
        }

        // 6. Config File Security
        if (substr(sprintf('%o', fileperms(ROOT_PATH . '/config.php')), -4) > '0644') {
            $report['recommended'][] = 'config.php permissions are too open. Set to 0644 or 0600.';
            $report['score'] -= 2;
        }

        // 7. Security Headers
        if ((Helpers::setting('security_headers_enabled', '1')) !== '1') {
            $report['recommended'][] = 'Security headers are disabled. Enable them in Security Settings.';
            $report['score'] -= 3;
        }

        $report['score'] = max(0, $report['score']);
        return $report;
    }

    private function getDbVersion(): string {
        try {
            return Database::getInstance()->fetchColumn("SELECT VERSION()");
        } catch (\Exception $e) {
            return 'Unknown';
        }
    }
}

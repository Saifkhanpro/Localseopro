<?php ob_start(); ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="h4 mb-0"><?= $pageTitle ?></h2>
    <div>
        <a href="/admin/leads/export?status=<?= htmlspecialchars($_GET['status'] ?? '') ?>" class="btn btn-outline-secondary me-2"><i class="bi bi-download"></i> Export CSV</a>
    </div>
</div>

<div class="row g-4 mb-4">
    <div class="col-md-4">
        <div class="card border-primary border-bottom border-3 shadow-sm h-100">
            <div class="card-body text-center">
                <h6 class="text-muted text-uppercase mb-1">New Unread Leads</h6>
                <h2 class="mb-0 text-primary fw-bold"><?= $counts['unread'] ?></h2>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card border-secondary border-bottom border-3 shadow-sm h-100">
            <div class="card-body text-center">
                <h6 class="text-muted text-uppercase mb-1">Total Leads (All Time)</h6>
                <h2 class="mb-0 text-dark fw-bold"><?= $counts['all'] ?></h2>
            </div>
        </div>
    </div>
</div>

<div class="card bg-white shadow-sm border-0 mb-4">
    <div class="card-body py-3 d-flex justify-content-between align-items-center bg-light rounded-top">
        <div class="d-flex gap-3 text-muted small">
            <a href="/admin/leads" class="text-decoration-none <?= !isset($_GET['status']) ? 'text-dark fw-bold' : 'text-muted' ?>">All</a> | 
            <a href="/admin/leads?status=new" class="text-decoration-none <?= ($_GET['status'] ?? '') === 'new' ? 'text-danger fw-bold' : 'text-muted' ?>">New</a> | 
            <a href="/admin/leads?status=contacted" class="text-decoration-none <?= ($_GET['status'] ?? '') === 'contacted' ? 'text-warning fw-bold' : 'text-muted' ?>">Contacted</a> | 
            <a href="/admin/leads?status=converted" class="text-decoration-none <?= ($_GET['status'] ?? '') === 'converted' ? 'text-success fw-bold' : 'text-muted' ?>">Converted</a>
        </div>
        
        <form method="GET" action="/admin/leads" class="d-flex">
            <?php if(isset($_GET['status'])): ?><input type="hidden" name="status" value="<?= htmlspecialchars($_GET['status']) ?>"><?php endif; ?>
            <div class="input-group input-group-sm">
                <input type="text" name="s" class="form-control" placeholder="Search name, phone, email..." value="<?= htmlspecialchars($_GET['s'] ?? '') ?>">
                <button class="btn btn-outline-secondary" type="submit"><i class="bi bi-search"></i></button>
            </div>
        </form>
    </div>

    <form method="POST" action="/admin/leads/action" id="bulk-form">
        <input type="hidden" name="csrf_token" value="<?= \Core\CSRF::generate() ?>">
        <div class="card-body border-bottom d-flex gap-2 py-2">
            <select name="action" class="form-select form-select-sm w-auto" required>
                <option value="">Bulk Actions</option>
                <option value="delete">Delete Permanently</option>
            </select>
            <button type="submit" class="btn btn-sm btn-outline-secondary" onclick="return confirm('Delete selected leads?');">Apply</button>
        </div>

        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead>
                    <tr>
                        <th style="width: 40px;"><input type="checkbox" class="form-check-input" id="selectAll"></th>
                        <th>Status</th>
                        <th>Contact Details</th>
                        <th>Service Interst</th>
                        <th>City</th>
                        <th>Date</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(empty($leads)): ?>
                        <tr><td colspan="7" class="text-center py-5 text-muted">No leads found.</td></tr>
                    <?php else: ?>
                        <?php foreach($leads as $lead): ?>
                            <tr class="<?= $lead['is_read'] == 0 ? 'table-primary bg-opacity-10' : '' ?>">
                                <td><input type="checkbox" name="ids[]" value="<?= $lead['id'] ?>" class="form-check-input row-chk"></td>
                                <td>
                                    <?php
                                        $badges = ['new' => 'danger', 'contacted' => 'warning', 'qualified' => 'info', 'converted' => 'success', 'closed' => 'secondary'];
                                        $col = $badges[$lead['status']] ?? 'primary';
                                    ?>
                                    <span class="badge bg-<?= $col ?>"><?= ucfirst($lead['status']) ?></span>
                                    <?php if($lead['is_read'] == 0): ?>
                                      <span class="badge bg-danger rounded-pill ms-1">UNREAD</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="fw-bold text-dark"><?= htmlspecialchars($lead['full_name']) ?></div>
                                    <div class="small">
                                        <a href="mailto:<?= htmlspecialchars($lead['email']) ?>" class="text-decoration-none text-muted"><i class="bi bi-envelope"></i> <?= htmlspecialchars($lead['email']) ?></a>
                                        <br>
                                        <a href="tel:<?= htmlspecialchars($lead['phone']) ?>" class="text-decoration-none text-muted"><i class="bi bi-telephone"></i> <?= htmlspecialchars($lead['phone']) ?></a>
                                    </div>
                                </td>
                                <td><?= htmlspecialchars($lead['service_needed']) ?></td>
                                <td><?= htmlspecialchars($lead['city'] ?? '--') ?></td>
                                <td class="small text-muted" title="<?= $lead['created_at'] ?>"><?= date('M j, Y h:ia', strtotime($lead['created_at'])) ?></td>
                                <td class="text-end">
                                    <a href="/admin/leads/<?= $lead['id'] ?>" class="btn btn-sm btn-primary">Details</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </form>
    
    <?php if($pagination['last_page'] > 1): ?>
    <div class="card-footer bg-white py-3">
        <nav>
            <ul class="pagination pagination-sm mb-0 justify-content-end">
                <?php for($i=1; $i<=$pagination['last_page']; $i++): ?>
                    <li class="page-item <?= $i == $pagination['current'] ? 'active' : '' ?>">
                        <a class="page-link" href="?p=<?= $i ?><?= isset($_GET['status']) ? '&status='.htmlspecialchars($_GET['status']) : '' ?><?= isset($_GET['s']) ? '&s='.htmlspecialchars($_GET['s']) : '' ?>"><?= $i ?></a>
                    </li>
                <?php endfor; ?>
            </ul>
        </nav>
    </div>
    <?php endif; ?>
</div>

<script>
    document.getElementById('selectAll').addEventListener('change', function(e) {
        document.querySelectorAll('.row-chk').forEach(chk => chk.checked = e.target.checked);
    });
</script>

<?php 
$content = ob_get_clean();
require dirname(__DIR__) . '/_layout.php';
?>

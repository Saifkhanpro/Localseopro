<?php
namespace Controllers\Admin;
use Core\Controller;
use Core\Helpers;
use Models\CityPage;

class CityController extends Controller {
    public function index() {
        $this->requireRole(['super_admin', 'admin', 'editor']);
        
        $cityModel = new CityPage();
        $page = (int)$this->input('p', 1);
        $perPage = 20;

        $s = $this->input('s');
        $where = "1=1";
        $params = [];
        if ($s) {
            $where .= " AND city_name LIKE ?";
            $params[] = "%{$s}%";
        }
        
        $paginated = $cityModel->paginate($page, $perPage, $where, $params, 'city_name ASC');

        $this->adminView('cities/index', [
            'pageTitle' => 'Local SEO City Pages',
            'cities' => $paginated['items'],
            'pagination' => $paginated,
            'counts' => [
                'all' => $cityModel->count(),
                'published' => $cityModel->count("status='published'"),
                'draft' => $cityModel->count("status='draft'")
            ]
        ]);
    }

    public function create() {
        $this->requireRole(['super_admin', 'admin', 'editor']);
        
        $this->adminView('cities/form', [
            'pageTitle' => 'Add New City Page',
            'city' => null
        ]);
    }

    public function edit(int $id) {
        $this->requireRole(['super_admin', 'admin', 'editor']);
        
        $cityModel = new CityPage();
        $city = $cityModel->find($id);

        if (!$city) {
            Helpers::flash('error', 'City not found.');
            $this->redirect('/admin/cities');
            return;
        }

        $featuredImageUrl = '';
        if ($city['featured_image_id']) {
            $db = \Core\Database::getInstance();
            $media = $db->fetch("SELECT file_path FROM {$db->t('media')} WHERE id = ?", [$city['featured_image_id']]);
            if ($media) $featuredImageUrl = '/' . $media['file_path'];
        }

        $this->adminView('cities/form', [
            'pageTitle' => 'Edit City Page',
            'city' => $city,
            'featuredImageUrl' => $featuredImageUrl
        ]);
    }

    public function save() {
        $this->requireRole(['super_admin', 'admin', 'editor']);
        $this->verifyCsrf();

        $id = (int)$this->input('id', 0);
        $cityModel = new CityPage();
        $user = $this->auth->user();

        $cityName = $this->input('city_name');
        $slug = Helpers::generateUniqueSlug($this->input('slug') ?: $cityName, 'city_pages', $id);
        
        $content = $_POST['content'] ?? '';
        $seoTitle = $this->input('seo_title');
        $focusKw = $this->input('focus_keyword', '');

        $seoAnalyzer = new \Core\SEOAnalyzer();
        $seoAnalysis = $seoAnalyzer->analyze($content, $seoTitle ?: "Local SEO Expert in {$cityName}", $focusKw);
        $readAnalysis = $seoAnalyzer->getReadability($content);

        $status = $this->input('status', 'draft');
        $publishedAt = $status === 'published' ? date('Y-m-d H:i:s') : null;

        $data = [
            'city_name' => $cityName,
            'slug' => $slug,
            'state_province' => $this->input('state_province', ''),
            'population' => $this->input('population', ''),
            'latitude' => $this->input('latitude') ?: null,
            'longitude' => $this->input('longitude') ?: null,
            'content' => $content,
            'featured_image_id' => $this->input('featured_image_id') ?: null,
            'status' => $status,
            'map_embed_code' => $this->input('map_embed_code', ''),
            'focus_keyword' => $focusKw,
            'secondary_keywords' => $this->input('secondary_keywords', ''),
            'seo_title' => $seoTitle,
            'meta_description' => $this->input('meta_description', ''),
            'robots_index' => $this->input('robots_index', 'default'),
            'robots_follow' => $this->input('robots_follow', 'default'),
            'robots_advanced' => implode(',', (array)$this->input('robots_advanced', [])),
            'canonical_url' => $this->input('canonical_url', ''),
            'readability_score' => $readAnalysis['score'],
            'seo_score' => $seoAnalysis['score'],
            'schema_type' => $this->input('schema_type', 'LocalBusiness'),
        ];

        if ($status === 'published' && $id == 0) $data['published_at'] = $publishedAt;

        if ($id > 0) {
            $cityModel->update($id, $data);
            $this->security->logActivity('update_city', $user['id'], 'city', $id, "Updated city: {$cityName}");
            Helpers::flash('success', 'City Page updated successfully.');
        } else {
            $id = $cityModel->create($data);
            $this->security->logActivity('create_city', $user['id'], 'city', $id, "Created city: {$cityName}");
            Helpers::flash('success', 'City Page created successfully.');
        }

        $cm = new \Core\CacheMonitor();
        $cm->clearType('pages');
        $this->redirect('/admin/cities/edit/' . $id);
    }
}

<?php
namespace Core;

class CSRF {
    private static $tokenName = '_csrf_token';

    public static function generate(): string {
        if (empty($_SESSION[self::$tokenName])) {
            $_SESSION[self::$tokenName] = bin2hex(random_bytes(32));
            $_SESSION['_csrf_time'] = time();
        }
        return $_SESSION[self::$tokenName];
    }

    public static function field(): string {
        return '<input type="hidden" name="' . self::$tokenName . '" value="' . self::generate() . '">';
    }

    public static function verify(?string $token = null): bool {
        $token = $token ?? ($_POST[self::$tokenName] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? ''));
        if (empty($token) || empty($_SESSION[self::$tokenName])) return false;
        $lifetime = defined('CSRF_SALT') ? 3600 : 3600;
        if (isset($_SESSION['_csrf_time']) && (time() - $_SESSION['_csrf_time']) > $lifetime) {
            self::regenerate();
            return false;
        }
        return hash_equals($_SESSION[self::$tokenName], $token);
    }

    public static function regenerate(): string {
        $_SESSION[self::$tokenName] = bin2hex(random_bytes(32));
        $_SESSION['_csrf_time'] = time();
        return $_SESSION[self::$tokenName];
    }

    public static function meta(): string {
        return '<meta name="csrf-token" content="' . self::generate() . '">';
    }
}

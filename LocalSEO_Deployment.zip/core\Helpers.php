<?php
namespace Core;

class Helpers {
    public static function setting(string $key, $default = '') {
        return $GLOBALS['settings'][$key] ?? $default;
    }

    public static function siteUrl(string $path = ''): string {
        $url = rtrim(self::setting('site_url', APP_URL), '/');
        return $path ? $url . '/' . ltrim($path, '/') : $url;
    }

    public static function assetUrl(string $path): string {
        $version = defined('APP_VERSION') ? APP_VERSION : '1.0.0';
        return self::siteUrl('assets/' . ltrim($path, '/')) . '?v=' . $version;
    }

    public static function uploadUrl(string $path): string {
        return self::siteUrl('uploads/' . ltrim($path, '/'));
    }

    public static function adminUrl(string $path = ''): string {
        return self::siteUrl('admin/' . ltrim($path, '/'));
    }

    public static function e(string $str): string {
        return htmlspecialchars($str, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }

    public static function slugify(string $text): string {
        $text = strtolower(trim($text));
        $text = preg_replace('/[^a-z0-9\s-]/', '', $text);
        $text = preg_replace('/[\s-]+/', '-', $text);
        return trim($text, '-');
    }

    public static function truncate(string $text, int $length = 160, string $suffix = '...'): string {
        $text = strip_tags($text);
        if (mb_strlen($text) <= $length) return $text;
        return mb_substr($text, 0, $length) . $suffix;
    }

    public static function timeAgo(string $datetime): string {
        $time = strtotime($datetime);
        $diff = time() - $time;
        if ($diff < 60) return 'just now';
        if ($diff < 3600) return floor($diff / 60) . 'm ago';
        if ($diff < 86400) return floor($diff / 3600) . 'h ago';
        if ($diff < 2592000) return floor($diff / 86400) . 'd ago';
        return date('M j, Y', $time);
    }

    public static function formatDate(string $datetime, string $format = ''): string {
        $format = $format ?: self::setting('date_format', 'M d, Y');
        return date($format, strtotime($datetime));
    }

    public static function formatNumber(int $num): string {
        if ($num >= 1000000) return round($num / 1000000, 1) . 'M';
        if ($num >= 1000) return round($num / 1000, 1) . 'K';
        return (string) $num;
    }

    public static function readingTime(string $content): int {
        $words = str_word_count(strip_tags($content));
        return max(1, (int) ceil($words / 200));
    }

    public static function wordCount(string $content): int {
        return str_word_count(strip_tags($content));
    }

    public static function excerpt(string $content, int $length = 55): string {
        $text = strip_tags($content);
        $words = explode(' ', $text);
        if (count($words) <= $length) return $text;
        return implode(' ', array_slice($words, 0, $length)) . '...';
    }

    public static function isCurrentUrl(string $path): bool {
        $current = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        return rtrim($current, '/') === rtrim($path, '/');
    }

    public static function isActiveNav(string $pattern): bool {
        $current = $_SERVER['REQUEST_URI'] ?? '/';
        return strpos($current, $pattern) === 0;
    }

    public static function flash(string $key, $value = null) {
        if ($value !== null) {
            $_SESSION['flash'][$key] = $value;
            return null;
        }
        $val = $_SESSION['flash'][$key] ?? null;
        unset($_SESSION['flash'][$key]);
        return $val;
    }

    public static function old(string $key, $default = '') {
        return $_SESSION['old_input'][$key] ?? $default;
    }

    public static function setOldInput(array $data): void {
        $_SESSION['old_input'] = $data;
    }

    public static function clearOldInput(): void {
        unset($_SESSION['old_input']);
    }

    public static function redirect(string $url, int $code = 302): void {
        header('Location: ' . $url, true, $code);
        exit;
    }

    public static function back(): void {
        $referer = $_SERVER['HTTP_REFERER'] ?? '/admin';
        header('Location: ' . $referer);
        exit;
    }

    public static function jsonResponse(array $data, int $code = 200): void {
        http_response_code($code);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
        exit;
    }

    public static function generateToken(int $length = 64): string {
        return bin2hex(random_bytes($length / 2));
    }

    public static function formatBytes(int $bytes, int $precision = 2): string {
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        $factor = floor((strlen($bytes) - 1) / 3);
        return sprintf("%.{$precision}f", $bytes / pow(1024, $factor)) . ' ' . $units[$factor];
    }

    public static function dynamicYear(): string {
        return date('Y');
    }

    public static function parseTemplate(string $template, array $vars = []): string {
        $defaults = [
            '{year}' => date('Y'),
            '{site_name}' => self::setting('site_title', 'LocalSEO.pk'),
            '{site_tagline}' => self::setting('site_tagline', ''),
            '{separator}' => self::setting('seo_title_separator', '|'),
        ];
        $vars = array_merge($defaults, $vars);
        return str_replace(array_keys($vars), array_values($vars), $template);
    }

    public static function getClientIP(): string {
        $headers = ['HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'REMOTE_ADDR'];
        foreach ($headers as $header) {
            if (!empty($_SERVER[$header])) {
                $ip = explode(',', $_SERVER[$header])[0];
                $ip = trim($ip);
                if (filter_var($ip, FILTER_VALIDATE_IP)) return $ip;
            }
        }
        return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    }

    public static function isMobile(): bool {
        $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
        return (bool) preg_match('/Mobile|Android|iPhone|iPad|iPod|webOS|BlackBerry|Opera Mini|IEMobile/i', $ua);
    }

    public static function whatsappUrl(string $number = '', string $message = ''): string {
        $number = $number ?: self::setting('whatsapp_number', '+923479007473');
        $message = $message ?: self::setting('whatsapp_default_message', '');
        $number = preg_replace('/[^0-9+]/', '', $number);
        $url = 'https://wa.me/' . ltrim($number, '+');
        if ($message) $url .= '?text=' . urlencode($message);
        return $url;
    }
}
